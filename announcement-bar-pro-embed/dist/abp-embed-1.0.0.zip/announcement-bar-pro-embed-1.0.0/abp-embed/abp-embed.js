/*! Announcement Bar Pro Embed 1.0.0 | MIT | (c) 3DP SIA */
/* Support: extension@3dp.lv. Source: abp-embed.js (this file, not minified) + source/ in the package.
   Contains the shared storefront script and pre-script of Announcement Bar Pro v2.4.1 (byte-identical in every edition). */
/* Announcement Bar Pro v2.4.1 — runs synchronously right after the bars (no inline script, CSP-friendly).
   Before the first paint it: keeps a single bar per id, moves a top bar to the top of <body> when the theme made it
   render in the footer, hides it while automatic colours / styles are worked out, removes messages the visitor
   closed, gives every A/B-tested message this browser's variant, decides campaign / referrer / new-or-returning rules
   and triggers that already fired in this visit, and starts with a message meant for this screen size (data-device,
   breakpoint 768 px) that is inside its weekly schedule (data-off). Exposed as window.abpPre() for boxes that the
   page adds later (the main script calls it). */
(function () {
  'use strict';

  // Do Not Track, Global Privacy Control, or the shop's consent tool set window.abpConsent = false before this script.
  // "Wait for cookie consent" (setting; data-consent="1" on the bars): until the shop's consent tool sets
  // window.abpConsent = true, nothing is stored, read or sent (A/B choice, visitor memory, campaign, statistics, GA4).
  function waitConsent() { return window.abpConsent !== true && !!document.querySelector('.abp[data-consent="1"]'); }
  function privacyOff() {
    var d = navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack;
    return d === '1' || d === 'yes' || navigator.globalPrivacyControl === true || window.abpConsent === false || waitConsent();
  }
  function storage(name) { try { var s = window[name]; s.getItem('abp'); return s; } catch (e) { return null; } }
  function readList(s, key) { try { var v = JSON.parse((s && s.getItem(key)) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function host(h) { return String(h || '').toLowerCase().replace(/^www\./, ''); }

  /* Campaign of this visit: UTM values of the landing URL and the external referrer, kept in sessionStorage for
     the rest of the visit (this tab only; nothing is stored with DNT / GPC / no consent, then only the URL counts). */
  var campaign = null;
  function getCampaign() {
    if (campaign) { return campaign; }
    var q = {}, ref = '', ss = privacyOff() ? null : storage('sessionStorage'), saved = null;
    String(location.search || '').replace(/^\?/, '').split('&').forEach(function (p) {
      var i = p.indexOf('=');
      if (i > 0) { try { q[decodeURIComponent(p.slice(0, i)).toLowerCase()] = decodeURIComponent(p.slice(i + 1).replace(/\+/g, ' ')).toLowerCase().trim(); } catch (e) { /* bad encoding */ } }
    });
    try { ref = document.referrer ? host(new URL(document.referrer).hostname) : ''; } catch (e2) { ref = ''; }
    if (ref === host(location.hostname)) { ref = ''; }
    if (q.utm_source || q.utm_medium || q.utm_campaign || ref) {
      campaign = { s: q.utm_source || '', m: q.utm_medium || '', c: q.utm_campaign || '', r: ref };
      try { if (ss) { ss.setItem('abp_utm', JSON.stringify(campaign)); } } catch (e3) { /* storage full / blocked */ }
    } else {
      try { saved = ss ? JSON.parse(ss.getItem('abp_utm') || 'null') : null; } catch (e4) { saved = null; }
      campaign = saved && typeof saved === 'object' ? { s: String(saved.s || ''), m: String(saved.m || ''), c: String(saved.c || ''), r: String(saved.r || '') } : { s: '', m: '', c: '', r: '' };
    }
    return campaign;
  }
  function campaignOk(rules) {
    var c = getCampaign();
    var has = function (list, v) { return !Array.isArray(list) || !list.length || (v !== '' && list.indexOf(v) !== -1); };
    var from = function (list, h) {
      if (!Array.isArray(list) || !list.length) { return true; }
      for (var i = 0; i < list.length; i++) { if (h !== '' && (h === list[i] || h.slice(-list[i].length - 1) === '.' + list[i])) { return true; } }
      return false;
    };
    return has(rules.s, c.s) && has(rules.m, c.m) && has(rules.c, c.c) && from(rules.r, c.r);
  }

  /* New or returning visitor: one first-party localStorage value (time of the first visit), "new" for 30 minutes.
     Unknown ('') with DNT / GPC / no consent or without storage — nothing is read or stored then. */
  var visitor = null;
  function getVisitor() {
    if (visitor !== null) { return visitor; }
    visitor = '';
    var ls = privacyOff() ? null : storage('localStorage');
    if (!ls) { return visitor; }
    try {
      var now = Date.now(), first = parseInt(ls.getItem('abp_v'), 10);
      if (!first || first > now) { first = now; ls.setItem('abp_v', String(now)); }
      visitor = now - first < 1800000 ? 'new' : 'returning';
    } catch (e) { visitor = ''; }
    return visitor;
  }

  function prep(bar) {
    var items = bar.querySelectorAll('.abp-item'), i, isBar = bar.getAttribute('data-abp') !== 'inline';

    // Footer fallback (theme header without <body>): a top bar still belongs at the top of the page.
    if (isBar && bar.getAttribute('data-fallback') === '1' && !/\babp-pos-bottom\b/.test(bar.className) && document.body) {
      document.body.insertBefore(bar, document.body.firstChild);
    }

    // Automatic colours and the derived styles are painted by the main script; hide until then (CSS reveals
    // the bar after 2 s anyway, so a blocked script can never hide it for good).
    var styled = false;
    for (i = 0; i < items.length; i++) { if ((items[i].getAttribute('data-style') || 'solid') !== 'solid' && !items[i].hasAttribute('data-img')) { styled = true; } }
    if (bar.getAttribute('data-color') === 'auto' || styled) { bar.className += ' abp-auto-pending'; }

    rules(bar, items);
    prepRest(bar, items, isBar);
  }

  /* A/B variant and campaign / referrer / visitor rules of a bar's messages; run again by abpPre.consent() when
     the visitor accepts cookies later on this page ("Wait for cookie consent"). */
  function rules(bar, items) {
    var i;
    // A/B test: a stable random variant per browser (localStorage "abp_ab"); without storage everyone sees A.
    var ab = null, off = privacyOff();
    if (!off) { try { ab = JSON.parse(window.localStorage.getItem('abp_ab') || '{}'); if (!ab || typeof ab !== 'object') { ab = {}; } } catch (e0) { ab = null; } }
    var abChanged = false;
    for (i = 0; i < items.length; i++) {
      if (items[i].getAttribute('data-ab') !== '1') { continue; }
      var id = items[i].getAttribute('data-id'), v = 'a';
      if (ab) {
        v = ab[id] === 'a' || ab[id] === 'b' ? ab[id] : (Math.random() < 0.5 ? 'a' : 'b');
        if (ab[id] !== v) { ab[id] = v; abChanged = true; }
      }
      items[i].setAttribute('data-variant', v);
    }
    if (ab && abChanged) {
      try { window.localStorage.setItem('abp_ab', JSON.stringify(ab)); } catch (e1) {
        // Cannot remember the choice: show A, so the visitor does not flip between variants.
        for (i = 0; i < items.length; i++) { if (items[i].getAttribute('data-ab') === '1') { items[i].setAttribute('data-variant', 'a'); } }
      }
    }

    // Campaign / referrer / visitor rules and triggers that already fired in this visit.
    var fired = readList(storage('sessionStorage'), 'abp_trig');
    for (i = 0; i < items.length; i++) {
      var el = items[i];
      if (el.hasAttribute('data-utm') || el.hasAttribute('data-vis')) {
        var ok = true, rule = null;
        if (el.hasAttribute('data-utm')) { try { rule = JSON.parse(el.getAttribute('data-utm')); } catch (e5) { rule = null; } ok = !!rule && campaignOk(rule); }
        if (ok && el.hasAttribute('data-vis')) { ok = getVisitor() === el.getAttribute('data-vis'); }
        if (ok) { el.removeAttribute('data-uoff'); } else { el.setAttribute('data-uoff', '1'); }
      }
      if (el.hasAttribute('data-trig') && fired.indexOf(el.getAttribute('data-id')) !== -1) { el.removeAttribute('data-toff'); }
    }
  }

  function prepRest(bar, items, isBar) {
    var i, now = Date.now();
    var read = function (name) {
      try {
        var v = JSON.parse(window[name].getItem('abp_dismiss2') || 'null');
        if (!v || !Array.isArray(v.k) || (v.t && v.t <= now)) { return []; }
        return v.k.filter(function (k) { return typeof k === 'string' && /^[0-9a-f]{12}$/.test(k); });
      } catch (e) { return []; }
    };
    var keys = bar.getAttribute('data-dismissible') === '1' ? read('localStorage').concat(read('sessionStorage')) : [];
    var mobile = window.matchMedia ? window.matchMedia('(max-width: 767px)').matches : window.innerWidth < 768;
    var fits = function (e) { var d = e.getAttribute('data-device'); return !e.hasAttribute('data-off') && !e.hasAttribute('data-coff') && !e.hasAttribute('data-uoff') && !e.hasAttribute('data-toff') && (!d || d === 'all' || (d === 'mobile') === mobile); };
    var max = parseInt(bar.getAttribute('data-max'), 10) || 0;

    var left = 0, first = null, shown = 0;
    for (i = 0; i < items.length; i++) {
      if (keys.length && keys.indexOf(items[i].getAttribute('data-key')) !== -1) {
        items[i].parentNode.removeChild(items[i]);
        continue;
      }
      left++;
      items[i].removeAttribute('data-over');
      if (fits(items[i])) {
        // "Messages per bar": the rest waits (highest priority first, as the server ordered them).
        if (max && shown >= max) { items[i].setAttribute('data-over', '1'); continue; }
        shown++;
        if (!first) { first = items[i]; }
      }
    }
    if (!left) {
      bar.style.display = 'none';
      bar.setAttribute('data-dismissed', '1');
      return;
    }
    // Folded by "hide after N seconds" earlier in this visit: start folded (the main script shows the tab).
    if (isBar && bar.hasAttribute('data-autohide') && readList(storage('sessionStorage'), 'abp_min').indexOf(bar.getAttribute('data-place')) !== -1) {
      bar.className += ' abp-min';
    }
    // Nothing for this screen size / time / visitor yet: stay hidden (the main script shows the bar when that changes).
    if (!first) { bar.style.display = 'none'; return; }
    var active = bar.querySelector('.abp-item.abp-active');
    if (!active || !fits(active) || active.hasAttribute('data-over')) {
      if (active) { active.className = active.className.replace(/(^|\s)abp-active(?=\s|$)/g, ' '); }
      first.className += ' abp-active';
      active = first;
    }
    bar.style.backgroundColor = active.style.backgroundColor;
    bar.style.color = active.style.color;
  }

  function run() {
    try {
      var list = document.querySelectorAll('.abp[data-abp], #abp-bar'), seen = {}; // #abp-bar: markup of an older (cached) template
      for (var i = 0; i < list.length; i++) {
        var bar = list[i];
        // A theme that renders the header twice must not show two bars.
        if (bar.id) {
          if (seen[bar.id] && seen[bar.id] !== bar) { bar.parentNode.removeChild(bar); continue; }
          seen[bar.id] = bar;
        }
        if (bar.getAttribute('data-abp-pre') === '1') { continue; }
        bar.setAttribute('data-abp-pre', '1');
        try { prep(bar); } catch (e1) { /* one broken box must not stop the others */ }
      }
    } catch (e) { /* never break the page */ }
  }

  window.abpPre = run;
  // Consent given later on this page: forget the "no storage" answers and decide A/B and visitor rules again.
  run.consent = function () {
    try {
      campaign = null;
      visitor = null;
      var list = document.querySelectorAll('.abp[data-abp-pre="1"]');
      for (var i = 0; i < list.length; i++) {
        try { rules(list[i], list[i].querySelectorAll('.abp-item')); } catch (e1) { /* one broken box must not stop the others */ }
      }
    } catch (e) { /* never break the page */ }
  };
  run();
})();

/* Announcement Bar Pro v2.4.1 — no dependencies. Adapts itself to the shop theme (see "Automatic adaptation").
   Runs every bar (top / bottom) and box (cart page, product page, mini-cart) on the page; features start only when a
   message uses them (triggers, auto-hide, forms, goals, GA4). */
(function () {
  'use strict';

  if (window.AnnouncementBarPro) { return; } // loaded twice (e.g. inside an AJAX fragment): keep the first copy

  /* ---------------- Shared: privacy, statistics, GA4 ---------------- */
  // Nothing is sent or stored for statistics when the visitor asks not to be tracked (Do Not Track / Global Privacy
  // Control) or the shop's consent tool sets window.abpConsent = false.
  // "Wait for cookie consent" (setting; data-consent="1" on the bars): until the shop's consent tool sets
  // window.abpConsent = true, nothing is stored, read or sent (A/B choice, visitor memory, campaign, statistics, GA4).
  function waitConsent() { return window.abpConsent !== true && !!document.querySelector('.abp[data-consent="1"]'); }
  function privacyOff() {
    var d = navigator.doNotTrack || window.doNotTrack || navigator.msDoNotTrack;
    return d === '1' || d === 'yes' || navigator.globalPrivacyControl === true || window.abpConsent === false || waitConsent();
  }
  var reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  function variant(el) { return el && el.getAttribute('data-variant') === 'b' ? 'b' : 'a'; }
  function inDoc(el) { return !!el && document.documentElement.contains(el); }

  /* Statistics (counters only): one "view" per message per browser session when it is really shown, one "click"
     when its button or a link in it is used, one "copy" when its coupon code is copied; A/B messages report their
     variant. No cookies or storage besides sessionStorage "abp_track". Every failure is silent. */
  var sent = {}, letter = { view: 'v', click: 'c', copy: 'p' };
  function seenInSession(key) {
    var list = [];
    try { list = JSON.parse(sessionStorage.getItem('abp_track') || '[]'); if (!Array.isArray(list)) { list = []; } } catch (e1) { list = []; }
    if (sent[key] || list.indexOf(key) !== -1) { return true; }
    sent[key] = 1;
    list.push(key);
    try { sessionStorage.setItem('abp_track', JSON.stringify(list.slice(-200))); } catch (e2) { /* storage blocked: memory only */ }
    return false;
  }
  function track(bar, el, type) {
    try {
      var id = el && parseInt(el.getAttribute('data-id'), 10), url = bar && bar.getAttribute('data-track');
      if (!id || id < 1 || !letter[type] || privacyOff()) { return; }
      ga(bar, el, 'abp_' + type);
      if (!url || seenInSession(letter[type] + id)) { return; }
      var fd = new FormData();
      fd.append('id', String(id));
      fd.append('type', type);
      fd.append('v', variant(el));
      if (!(navigator.sendBeacon && navigator.sendBeacon(url, fd)) && window.fetch) {
        window.fetch(url, { method: 'POST', body: fd, keepalive: true, credentials: 'same-origin' }).catch(function () {});
      }
    } catch (e) { /* statistics must never break the bar */ }
  }
  /* GA4: only when the shop already loads it (gtag or a GTM dataLayer). Message number, version and placement only. */
  function ga(bar, el, name) {
    try {
      if (!bar || bar.getAttribute('data-ga') !== '1' || privacyOff()) { return; }
      var id = parseInt(el.getAttribute('data-id'), 10);
      if (!id || seenInSession('g' + name.slice(4, 6) + id)) { return; }
      var params = { abp_message_id: id, abp_variant: variant(el), abp_placement: bar.getAttribute('data-place') || '' };
      if (typeof window.gtag === 'function') { window.gtag('event', name, params); } else if (window.dataLayer && typeof window.dataLayer.push === 'function') {
        var ev = { event: name };
        for (var k in params) { if (Object.prototype.hasOwnProperty.call(params, k)) { ev[k] = params[k]; } }
        window.dataLayer.push(ev);
      }
    } catch (e) { /* analytics must never break the bar */ }
  }

  var instances = [];

  function init(bar) {
    if (!bar || bar.getAttribute('data-dismissed') === '1' || bar.abpInit) { return; }
    bar.abpInit = true;

    var inline = bar.getAttribute('data-abp') === 'inline';
    var mode = inline ? 'stack' : bar.getAttribute('data-mode');
    var timer = null, tickTimer = null, index = 0, paused = false, userPaused = false;
    // Offset between server and visitor clock, so a wrong PC clock cannot shift countdowns/expiry/schedules.
    var skew = (parseInt(bar.getAttribute('data-now'), 10) || Date.now()) - Date.now();
    function serverNow() { return Date.now() + skew; }
    // Store time zone offset (seconds) for the weekly schedule and cut-off times.
    var tz = parseInt(bar.getAttribute('data-tz'), 10) || 0;

    if (mode === 'marquee' && reduced) {
      mode = 'rotate';
      bar.className = bar.className.replace('abp-mode-marquee', 'abp-mode-rotate');
    }

    /* ---------------- A/B variant (normally set by the pre-script; here only if it did not run) ---------------- */
    Array.prototype.forEach.call(bar.querySelectorAll('.abp-item[data-ab="1"]'), function (el) {
      if (!el.hasAttribute('data-variant')) { el.setAttribute('data-variant', 'a'); }
    });

    /* ---------------- Weekly schedule (store time) ----------------
       data-wd = ISO weekdays (1 = Monday … 7 = Sunday), data-t1/data-t2 = daily window HH:MM; a window that
       crosses midnight belongs to the day it starts on. Messages outside are marked data-off (hidden by CSS). */
    function minutes(t) { var m = /^(\d{2}):(\d{2})$/.exec(t || ''); return m ? parseInt(m[1], 10) * 60 + parseInt(m[2], 10) : -1; }
    function isOpen(el) {
      var wd = el.getAttribute('data-wd') || '', t1 = minutes(el.getAttribute('data-t1')), t2 = minutes(el.getAttribute('data-t2'));
      if (!wd && t1 < 0) { return true; }
      var d = new Date(serverNow() + tz * 1000), day = d.getUTCDay() || 7, prev = day === 1 ? 7 : day - 1, min = d.getUTCHours() * 60 + d.getUTCMinutes();
      var has = function (x) { return !wd || wd.indexOf(String(x)) !== -1; };
      if (t1 < 0 || t2 < 0 || t1 === t2) { return has(day); }
      if (t1 < t2) { return has(day) && min >= t1 && min < t2; }
      return (min >= t1 && has(day)) || (min < t2 && has(prev));
    }
    function scheduled() { return bar.querySelectorAll('.abp-item[data-wd], .abp-item[data-t1]'); }
    // Returns true when any message switched on or off.
    function applySchedule() {
      var changed = false;
      Array.prototype.forEach.call(scheduled(), function (el) {
        var off = !isOpen(el);
        if (off !== el.hasAttribute('data-off')) { changed = true; if (off) { el.setAttribute('data-off', '1'); } else { el.removeAttribute('data-off'); } }
      });
      return changed;
    }
    // Next daily / weekly cut-off after now (store time): "d|14:00|67" = daily at 14:00 except Sat+Sun, "w|14:00|5".
    function nextCutoff(rule, now) {
      var m = /^([dw])\|(\d{2}):(\d{2})\|([1-7]*)$/.exec(rule || '');
      if (!m) { return 0; }
      var local = new Date(now + tz * 1000);
      for (var i = 0; i < 8; i++) {
        var at = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() + i, parseInt(m[2], 10), parseInt(m[3], 10)) - tz * 1000;
        var dow = new Date(at + tz * 1000).getUTCDay() || 7;
        if (at > now && (m[1] === 'w' ? m[4] === String(dow) : m[4].indexOf(String(dow)) === -1)) { return at; }
      }
      return 0;
    }

    /* ---------------- Which messages may show ----------------
       Device (768 px, like the CSS), schedule (data-off), cart conditions (data-coff), campaign / visitor rules
       (data-uoff, decided by the pre-script), triggers not fired yet (data-toff); then "Messages per bar" (data-max). */
    var mq = window.matchMedia ? window.matchMedia('(max-width: 767px)') : null;
    var closed = false, deviceHidden = false;
    var max = parseInt(bar.getAttribute('data-max'), 10) || 0;
    function isMobile() { return mq ? mq.matches : window.innerWidth < 768; }
    function fits(el) { var d = el.getAttribute('data-device'); return !el.hasAttribute('data-off') && !el.hasAttribute('data-coff') && !el.hasAttribute('data-uoff') && !el.hasAttribute('data-toff') && (!d || d === 'all' || (d === 'mobile') === isMobile()); }
    function allItems() { return bar.querySelectorAll('.abp-item'); }
    function items() {
      var list = Array.prototype.filter.call(allItems(), fits);
      Array.prototype.forEach.call(allItems(), function (el) { var over = max > 0 && list.indexOf(el) >= max; if (over !== el.hasAttribute('data-over')) { if (over) { el.setAttribute('data-over', '1'); } else { el.removeAttribute('data-over'); } } });
      return max > 0 ? list.slice(0, max) : list;
    }
    function hidden() { return bar.style.display === 'none' || bar.classList.contains('abp-min'); }

    // Views: the active message (rotate) or every message on screen (marquee, stack).
    function trackShown() {
      if (hidden()) { return; }
      var list = items();
      if (mode === 'rotate') { track(bar, list[index], 'view'); } else { list.forEach(function (el) { track(bar, el, 'view'); }); }
    }

    /* ---------------- Automatic adaptation to the theme (bars only) ----------------
       Works on any theme without settings:
       - fixed / sticky headers stuck to the top are moved down below the bar while the bar is on screen;
       - fixed elements stuck to the bottom (cookie banners, mobile tab bars) lift a bottom bar above them;
       - the bar stacks above those elements (z-index);
       - "Automatic" colours take the theme's main colour and a readable text colour;
       - icons are dropped when the theme has no Font Awesome (no empty squares). */
    var isTop = !bar.classList.contains('abp-pos-bottom');
    var cache = { top: [], bottom: [] }, lastScan = 0;

    function px(v) { var n = parseFloat(v); return isNaN(n) ? 0 : n; }

    function candidates() {
      return document.querySelectorAll('body > *, body > * > *, header, nav, [class*="sticky"], [class*="fixed"], [id*="header"], [class*="header"], [class*="navbar"], [class*="cookie"], [id*="cookie"], [class*="consent"]');
    }

    // Find wide fixed/sticky bars resting near the top (a stack of them is fine) or on the bottom edge.
    // Runs on load, resize and at most once a second while scrolling — never on every frame.
    function rescan() {
      if (inline) { return; }
      lastScan = Date.now();
      var list = candidates(), vw = window.innerWidth, vh = window.innerHeight, top = [], bottom = [];
      var known = cache.top.map(function (e) { return e.el; });
      for (var i = 0; i < list.length; i++) {
        var el = list[i];
        if (el === bar || bar.contains(el) || el.contains(bar) || (el.className && /abp-(spacer|bar|tab)/.test(String(el.className)))) { continue; }
        var k = known.indexOf(el);
        if (k !== -1) { top.push(cache.top[k]); continue; } // keep what we already moved (to restore it later)
        var cs = window.getComputedStyle(el);
        if ((cs.position !== 'fixed' && cs.position !== 'sticky') || cs.display === 'none' || cs.visibility === 'hidden') { continue; }
        var r = el.getBoundingClientRect();
        if (r.width < vw * 0.5 || r.height <= 0 || r.height > vh * 0.6 || r.bottom <= 0) { continue; }
        if (cs.top !== 'auto' && px(cs.top) <= vh * 0.25 && r.top <= px(cs.top) + 2) {
          top.push({ el: el, orig: px(cs.top), h: r.height, inline: el.style.getPropertyValue('top'), prio: el.style.getPropertyPriority('top'), last: null, z: parseInt(cs.zIndex, 10) });
        } else if (cs.position === 'fixed' && cs.bottom !== 'auto' && px(cs.bottom) <= 2) {
          bottom.push({ el: el, z: parseInt(cs.zIndex, 10) });
        }
      }
      // Drop nested elements (the outer one moves them all).
      cache.top = top.filter(function (a) { return !top.some(function (b) { return b !== a && b.el.contains(a.el); }); });
      cache.bottom = bottom;
    }

    function restoreEdges() {
      cache.top.forEach(function (e) {
        if (e.last === null) { return; }
        e.el.style.removeProperty('top');
        if (e.inline) { e.el.style.setProperty('top', e.inline, e.prio); }
        e.last = null;
      });
      bar.style.bottom = '';
    }

    function adaptEdges() {
      if (inline) { return; }
      if (hidden()) { restoreEdges(); return; }
      var maxZ = 0;
      if (isTop) {
        // Reads first, writes after (no layout thrashing).
        var br = bar.getBoundingClientRect(), below = Math.max(0, Math.round(br.bottom));
        // Move the header stack only if part of it actually sits over the bar; a header the theme already
        // pads content for leaves the bar visible underneath it and stays where it is.
        var covers = br.bottom > 0 && cache.top.some(function (e) { return e.orig < br.bottom - 1 && e.orig + e.h > br.top + 1; });
        cache.top.forEach(function (e) {
          if (!isNaN(e.z)) { maxZ = Math.max(maxZ, e.z); }
          var want = covers ? e.orig + below : null;
          if (want === e.last) { return; }
          if (want === null) {
            e.el.style.removeProperty('top');
            if (e.inline) { e.el.style.setProperty('top', e.inline, e.prio); }
          } else {
            // Plain inline value (no !important): theme scripts that hide the header on scroll still win.
            e.el.style.setProperty('top', want + 'px');
          }
          e.last = want;
        });
      } else {
        var lift = 0, vh = window.innerHeight;
        cache.bottom.forEach(function (e) {
          var r = e.el.getBoundingClientRect();
          if (r.height > 0 && r.top < vh && window.getComputedStyle(e.el).display !== 'none') { lift = Math.max(lift, Math.round(vh - r.top)); }
          if (!isNaN(e.z)) { maxZ = Math.max(maxZ, e.z); }
        });
        bar.style.bottom = lift ? lift + 'px' : '';
      }
      // Stay above the theme's fixed bars, but below modal windows (Bootstrap backdrop 1040+).
      bar.style.zIndex = maxZ >= 1030 ? String(Math.min(maxZ + 1, 1039)) : '';
      if (tab) { tab.style.zIndex = bar.style.zIndex; }
    }

    /* ---------------- Colours and styles ----------------
       Every style keeps WCAG contrast of at least 4.5:1 between the text and what is behind it. */
    function parseRgb(c) {
      var m = /rgba?\(([^)]+)\)/.exec(c || '');
      if (!m) { return null; }
      var p = m[1].split(/[\s,\/]+/).filter(function (x) { return x !== ''; }).map(parseFloat);
      if (p.length < 3 || (p.length > 3 && p[3] === 0)) { return null; }
      return p.slice(0, 3);
    }
    function hexRgb(h) { return /^#[0-9a-f]{6}$/i.test(h || '') ? [1, 3, 5].map(function (i) { return parseInt(h.substr(i, 2), 16); }) : null; }
    function css(rgb) { return 'rgb(' + rgb.map(function (v) { return Math.max(0, Math.min(255, Math.round(v))); }).join(',') + ')'; }
    function rgba(rgb, a) { return 'rgba(' + rgb.map(function (v) { return Math.max(0, Math.min(255, Math.round(v))); }).join(',') + ',' + a + ')'; }
    function mix(a, b, t) { return a.map(function (v, i) { return v + (b[i] - v) * t; }); }
    var WHITE = [255, 255, 255], BLACK = [0, 0, 0], INK = [17, 17, 17];

    function luminance(rgb) {
      var c = rgb.map(function (v) { v = Math.max(0, Math.min(255, v)) / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
      return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    }

    function contrast(l1, l2) {
      return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    }
    function ratio(a, b) { return contrast(luminance(a), luminance(b)); }

    // Text colour with the higher WCAG contrast (white or #111111). If even that stays below 4.5:1
    // (mid-tone theme colours), the background is darkened or lightened just enough to reach it.
    function readable(rgb) {
      var dark = luminance(INK), bg = rgb.slice(), fg, toward;
      fg = contrast(luminance(bg), 1) >= contrast(luminance(bg), dark) ? '#ffffff' : '#111111';
      toward = fg === '#ffffff' ? 0 : 255;
      for (var i = 0; i < 20 && contrast(luminance(bg), fg === '#ffffff' ? 1 : dark) < 4.5; i++) {
        bg = bg.map(function (v) { return v + (toward - v) * 0.08; });
      }
      return { bg: bg, fg: fg };
    }
    // Moves colour c toward target until it reaches the wanted contrast against every colour in "against".
    function push(c, target, against, want) {
      var out = c.slice();
      for (var i = 0; i < 40 && against.some(function (a) { return ratio(out, a) < want; }); i++) { out = mix(out, target, 0.08); }
      return out;
    }

    var glassOk = !!(window.CSS && CSS.supports && (CSS.supports('backdrop-filter', 'blur(2px)') || CSS.supports('-webkit-backdrop-filter', 'blur(2px)')));

    // Computes the look of one message: base colour (theme colour in Automatic mode, else its own) + style.
    function skinOf(base, ownFg, style) {
      var s = readable(base), fg = ownFg ? ownFg : (s.fg === '#ffffff' ? WHITE : INK), bg = ownFg ? base : s.bg;
      var light = luminance(fg) > luminance(bg);
      var out = { bg: css(bg), image: '', fg: css(fg), btnBg: css(fg), btnFg: css(bg), accent: css(fg), glass: false };
      if (style === 'gradient') {
        // Custom colours below 4.5:1: the first stop is moved away from the text colour just enough.
        if (ratio(fg, bg) < 4.5) { bg = push(bg, light ? BLACK : WHITE, [fg], 4.5); out.bg = css(bg); out.btnFg = css(bg); }
        // Second stop: same hue family, moved away from the text colour (only raises the contrast).
        var c2 = mix(bg, light ? BLACK : WHITE, 0.3);
        c2 = [c2[0] * 0.92 + c2[2] * 0.08, c2[1], c2[2] * 0.9 + c2[0] * 0.1];
        if (ratio(fg, c2) < Math.max(4.5, ratio(fg, bg) - 0.01)) { c2 = mix(bg, light ? BLACK : WHITE, 0.3); }
        out.image = 'linear-gradient(100deg,' + css(bg) + ' 0%,' + css(mix(bg, c2, 0.5)) + ' 55%,' + css(c2) + ' 100%)';
      } else if (style === 'soft' || style === 'minimal') {
        var tint = style === 'soft' ? mix(base, WHITE, 0.86) : mix(base, WHITE, 0.965);
        var text = push(style === 'soft' ? mix(base, BLACK, 0.55) : mix(base, BLACK, 0.78), BLACK, [tint], 4.5);
        var solid = readable(base);
        out.bg = css(tint); out.fg = css(text);
        out.accent = css(push(base, BLACK, [tint], 3));
        out.btnBg = css(solid.bg); out.btnFg = solid.fg;
      } else if (style === 'glass' && glassOk) {
        // Translucent: the page behind can be white or black — the text must stay readable on both.
        var a = 0.8, worst = function (c) { return [mix(c, WHITE, 1 - a), mix(c, BLACK, 1 - a)]; };
        var cand = [WHITE, INK].map(function (f) {
          var c = base.slice();
          for (var i = 0; i < 30 && worst(c).some(function (w) { return ratio(f, w) < 4.5; }); i++) { c = mix(c, f === WHITE ? BLACK : WHITE, 0.08); }
          return { f: f, c: c, d: Math.abs(luminance(c) - luminance(base)) };
        });
        var pick = cand[0].d <= cand[1].d ? cand[0] : cand[1];
        if (ownFg && !worst(base).some(function (w) { return ratio(ownFg, w) < 4.5; })) { pick = { f: ownFg, c: base }; }
        out.bg = rgba(pick.c, a); out.fg = css(pick.f); out.btnBg = css(pick.f); out.btnFg = css(pick.c); out.accent = css(pick.f); out.glass = true;
      }
      return out;
    }

    var theme = null; // theme colour (Automatic mode), read after load
    function paintItem(el) {
      var style = el.getAttribute('data-style') || 'solid', auto = bar.getAttribute('data-color') === 'auto';
      var base = auto && theme ? theme : hexRgb(el.getAttribute('data-c')), own = auto ? null : hexRgb(el.getAttribute('data-t'));
      if (!base || el.hasAttribute('data-img')) { return; } // a background image keeps its own colour overlay
      if (!auto && style === 'solid') { return; } // custom colours are not changed
      var k = skinOf(base, own, style), st = el.style;
      st.backgroundColor = k.bg; st.backgroundImage = k.image; st.color = k.fg;
      st.setProperty('--abp-btn-bg', k.btnBg); st.setProperty('--abp-btn-fg', k.btnFg); st.setProperty('--abp-accent', k.accent);
      el.abpGlass = k.glass;
    }
    function paintAll() { Array.prototype.forEach.call(allItems(), paintItem); var list = items(); paintBar(list[index] || list[0]); }

    // The theme's main colour: primary buttons, then the menu / navbar, then the link colour.
    function themeColour() {
      var probes = ['.btn-primary', '#menu', '.navbar-inverse', '#top-menu', '.main-menu', '.navbar', 'header nav', 'button[type="submit"]', '.btn', 'header'];
      for (var i = 0; i < probes.length; i++) {
        var els = document.querySelectorAll(probes[i]);
        for (var j = 0; j < els.length && j < 6; j++) {
          if (els[j].closest && els[j].closest('.abp')) { continue; }
          if (!els[j].getBoundingClientRect().width) { continue; }
          var rgb = parseRgb(window.getComputedStyle(els[j]).backgroundColor);
          if (rgb) { var l = luminance(rgb); if (l < 0.8 && l > 0.005) { return rgb; } }
        }
      }
      var links = document.querySelectorAll('a[href]');
      for (var k = 0; k < links.length && k < 40; k++) {
        if (links[k].closest && links[k].closest('.abp')) { continue; }
        var c = parseRgb(window.getComputedStyle(links[k]).color);
        if (c && luminance(c) < 0.5) { return c; }
      }
      return null;
    }

    function applyAutoColours() {
      if (bar.getAttribute('data-color') === 'auto') { theme = themeColour(); }
      paintAll();
      bar.classList.remove('abp-auto-pending');
    }

    // Font Awesome missing in the theme → remove icons instead of showing empty boxes.
    function checkIcons() {
      bar.querySelectorAll('i[class*="fa-"]').forEach(function (icon) {
        var font = window.getComputedStyle(icon).fontFamily || '', before = window.getComputedStyle(icon, '::before').content;
        // Keep it if any icon font styles it or its ::before has a glyph (FA 4/5/6, other icon fonts, SVG kits).
        if (/awesome|icon/i.test(font) || (before && before !== 'none' && before !== 'normal' && before !== '""')) { return; }
        icon.parentNode.removeChild(icon);
      });
    }

    function paintBar(item) {
      if (!item) { return; }
      bar.style.backgroundColor = item.style.backgroundColor;
      bar.style.backgroundImage = item.style.backgroundImage || '';
      bar.style.color = item.style.color;
      bar.classList.toggle('abp-glass', !!item.abpGlass);
      if (tab) { tab.style.backgroundColor = item.style.backgroundColor; tab.style.color = item.style.color; }
    }

    // Some themes put the whole page in an absolutely positioned wrapper (OpenCart 4.1: #container).
    // Then <body> is short, CSS "sticky" cannot work and body padding does not reach the page bottom.
    function wrappers() {
      var out = [], kids = document.body.children;
      for (var i = 0; i < kids.length; i++) {
        if (!/(^|\s)abp(-spacer|-tab)?(\s|$)/.test(String(kids[i].className)) && window.getComputedStyle(kids[i]).position === 'absolute' && kids[i].offsetHeight > window.innerHeight / 2) { out.push(kids[i]); }
      }
      return out;
    }

    function fitBody() {
      if (inline) { return; }
      var hide = hidden();
      if (bar.classList.contains('abp-pos-bottom')) {
        document.body.style.paddingBottom = hide ? '' : bar.offsetHeight + 'px';
        // With an absolutely positioned page wrapper, body padding does not extend the page: add an
        // invisible block below the wrapper instead, so the footer can scroll above the fixed bar.
        var ws = wrappers(), end = 0;
        ws.forEach(function (w) { end = Math.max(end, w.offsetTop + w.offsetHeight); });
        var sp = document.getElementById('abp-bottom-spacer');
        if (ws.length && !hide) {
          if (!sp) { sp = document.createElement('div'); sp.id = 'abp-bottom-spacer'; sp.className = 'abp-spacer'; sp.setAttribute('aria-hidden', 'true'); document.body.appendChild(sp); }
          sp.style.cssText = 'position:absolute;left:0;width:1px;pointer-events:none;top:' + end + 'px;height:' + bar.offsetHeight + 'px;';
          if (window.ResizeObserver && !bar.abpRo) { bar.abpRo = new ResizeObserver(function () { fitBody(); }); ws.forEach(function (w) { bar.abpRo.observe(w); }); }
        } else if (sp) {
          sp.parentNode.removeChild(sp);
        }
      }
      adaptEdges();
      if (bar.classList.contains('abp-sticky')) {
        // CSS sticky works only when <body> is as tall as the page; otherwise pin the bar and keep its space.
        var broken = document.body.offsetHeight < document.documentElement.scrollHeight - 2 || wrappers().length > 0;
        bar.classList.toggle('abp-pinned', broken && !hide);
        var spacer = bar.nextElementSibling && bar.nextElementSibling.className === 'abp-spacer' ? bar.nextElementSibling : null;
        if (broken && !hide) {
          if (!spacer) { spacer = document.createElement('div'); spacer.className = 'abp-spacer'; bar.parentNode.insertBefore(spacer, bar.nextSibling); }
          spacer.style.height = bar.offsetHeight + 'px';
        } else if (spacer) {
          spacer.parentNode.removeChild(spacer);
        }
      }
    }

    // Rotate mode: reserve the height of the tallest message so the page does not jump on every change.
    function stabilise() {
      var trackEl = bar.querySelector('.abp-track');
      if (!trackEl) { return; }
      trackEl.style.minHeight = '';
      if (mode !== 'rotate') { return; }
      var list = items(), maxH = 0, min = Infinity;
      for (var i = 0; i < list.length; i++) {
        var was = list[i].style.display;
        list[i].style.display = 'block';
        var h = list[i].offsetHeight;
        maxH = Math.max(maxH, h); min = Math.min(min, h);
        list[i].style.display = was;
      }
      // Reserve the tallest height only when messages are similar; one very long message must not
      // turn every short one into a huge bar (e.g. on phones).
      if (maxH && maxH <= min * 2.5) { trackEl.style.minHeight = maxH + 'px'; }
    }

    var navs = bar.querySelectorAll('.abp-nav');
    function show(i, back) {
      var list = items();
      if (!list.length) { return; }
      index = (i + list.length) % list.length;
      bar.classList.toggle('abp-back', !!back);
      var all = allItems();
      for (var n = 0; n < all.length; n++) {
        if (all[n] === list[index]) { all[n].classList.add('abp-active'); } else { all[n].classList.remove('abp-active'); }
      }
      for (var b = 0; b < navs.length; b++) { navs[b].hidden = mode !== 'rotate' || list.length < 2; }
      if (pauseBtn) { pauseBtn.hidden = !(mode === 'marquee' || (mode === 'rotate' && list.length > 1)); }
      paintBar(list[index]);
      fitBody();
      trackShown();
    }

    function stopRotate() { if (timer) { clearInterval(timer); timer = null; } }

    function startRotate() {
      stopRotate();
      if (paused || userPaused || mode !== 'rotate' || items().length < 2 || hidden()) { return; }
      var ms = Math.max(2, parseInt(bar.getAttribute('data-interval'), 10) || 5) * 1000;
      timer = setInterval(function () { if (!inDoc(bar)) { stopRotate(); return; } show(index + 1); }, ms);
    }

    function startMarquee() {
      if (mode !== 'marquee') { return; }
      var trackEl = bar.querySelector('.abp-track'), view = bar.querySelector('.abp-viewport');
      if (!trackEl || !view) { return; }
      trackEl.classList.remove('abp-run');
      var speed = Math.max(20, parseInt(bar.getAttribute('data-speed'), 10) || 60);
      var from = view.clientWidth, to = trackEl.scrollWidth;
      trackEl.style.setProperty('--abp-from', from + 'px');
      trackEl.style.setProperty('--abp-to', -to + 'px');
      trackEl.style.setProperty('--abp-duration', ((from + to) / speed).toFixed(2) + 's');
      void trackEl.offsetWidth; // restart animation
      trackEl.classList.add('abp-run');
    }

    function relayout() { rescan(); stabilise(); show(Math.min(index, Math.max(items().length - 1, 0))); startRotate(); startMarquee(); fitBody(); }

    function startTick() {
      if (!tickTimer && bar.querySelector('.abp-countdown, .abp-item[data-end], .abp-item[data-wd], .abp-item[data-t1]')) { tickTimer = setInterval(tick, 1000); }
    }

    function hideBar() {
      stopRotate();
      bar.style.display = 'none';
      fitBody();
      restoreEdges();
    }

    // Something changed which messages may be shown (screen size crossed 768 px, schedule, expiry, cart, trigger):
    // rebuild from the messages that fit now, hide the bar when none is left, show it again when one is.
    function refreshVisible() {
      if (closed) { return; }
      if (!items().length) {
        if (bar.style.display !== 'none') { deviceHidden = true; hideBar(); }
        return;
      }
      if (deviceHidden || bar.style.display === 'none') {
        deviceHidden = false;
        bar.style.display = '';
      }
      index = 0;
      relayout();
      armAutohide();
    }

    function pad(n) { return (n < 10 ? '0' : '') + n; }

    // Countdowns, weekly schedules and removal of messages whose end time passed while the page is open.
    // A daily / weekly cut-off (data-recur) starts again for the next cut-off instead.
    function tick() {
      if (!inDoc(bar)) { clearInterval(tickTimer); tickTimer = null; return; }
      var now = serverNow(), changed = applySchedule(), list = allItems();
      for (var i = list.length - 1; i >= 0; i--) {
        var end = parseInt(list[i].getAttribute('data-end'), 10);
        if (end && end <= now) { list[i].parentNode.removeChild(list[i]); changed = true; }
      }
      var nodes = bar.querySelectorAll('.abp-countdown');
      for (var c = 0; c < nodes.length; c++) {
        var cEnd = parseInt(nodes[c].getAttribute('data-end'), 10), left = Math.floor((cEnd - now) / 1000);
        if ((!cEnd || left <= 0) && nodes[c].getAttribute('data-recur')) {
          cEnd = nextCutoff(nodes[c].getAttribute('data-recur'), now);
          if (cEnd) { nodes[c].setAttribute('data-end', String(cEnd)); left = Math.floor((cEnd - now) / 1000); }
        }
        if (!cEnd || left <= 0) {
          var item = nodes[c].closest ? nodes[c].closest('.abp-item') : null;
          if (item && item.parentNode) { item.parentNode.removeChild(item); changed = true; }
          continue;
        }
        var d = Math.floor(left / 86400), h = Math.floor(left % 86400 / 3600), m = Math.floor(left % 3600 / 60), s = left % 60;
        nodes[c].textContent = (d > 0 ? d + (bar.getAttribute('data-days-label') || 'd') + ' ' : '') + pad(h) + ':' + pad(m) + ':' + pad(s);
      }
      if (changed) { refreshVisible(); }
      if (!bar.querySelector('.abp-countdown, .abp-item[data-end], .abp-item[data-wd], .abp-item[data-t1]') && tickTimer) { clearInterval(tickTimer); tickTimer = null; }
    }

    // Keyboard users: continue at the first focusable element after the bar, not at <body>.
    function focusAfter(focusWasInside) {
      if (!focusWasInside) { return; }
      var next = document.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      for (var k2 = 0; k2 < next.length; k2++) {
        if (!bar.contains(next[k2]) && (bar.compareDocumentPosition(next[k2]) & 4) && next[k2].offsetParent !== null) { next[k2].focus(); break; }
      }
    }

    var close = bar.querySelector('.abp-close');
    if (close) {
      close.addEventListener('click', function () {
        var days = parseInt(bar.getAttribute('data-days'), 10) || 0, now = Date.now();
        try {
          var keep = days > 0 ? localStorage : sessionStorage, drop = days > 0 ? sessionStorage : localStorage;
          // Remember each closed message (merged with earlier ones), so messages that expire or are
          // switched off do not bring the bar back; only new or edited messages do.
          var prev = [];
          try { var v = JSON.parse(keep.getItem('abp_dismiss2') || 'null'); if (v && Array.isArray(v.k) && (!v.t || v.t > now)) { prev = v.k.filter(function (k) { return typeof k === 'string' && /^[0-9a-f]{12}$/.test(k); }); } } catch (e1) { prev = []; }
          var list = items(), keys = prev.slice(); // only what this screen size showed
          for (var j = 0; j < list.length; j++) { var k = list[j].getAttribute('data-key'); if (k && keys.indexOf(k) === -1) { keys.push(k); } }
          keep.setItem('abp_dismiss2', JSON.stringify({ k: keys.slice(-200), t: days > 0 ? now + days * 86400000 : 0 }));
          drop.removeItem('abp_dismiss2');
          keep.removeItem('abp_dismiss'); drop.removeItem('abp_dismiss'); // pre-2.0.3 format
        } catch (e) { /* storage blocked: bar just hides for this page view */ }
        var focusWasInside = bar.contains(document.activeElement);
        closed = true;
        if (tickTimer) { clearInterval(tickTimer); tickTimer = null; }
        clearTimeout(minTimer);
        if (tab) { tab.hidden = true; }
        hideBar();
        focusAfter(focusWasInside);
      });
    }

    // Previous / next message (rotate mode). Buttons: reachable with the keyboard, labelled for screen readers.
    Array.prototype.forEach.call(navs, function (btn) {
      btn.addEventListener('click', function () {
        var back = btn.classList.contains('abp-prev');
        show(index + (back ? -1 : 1), back);
        startRotate();
      });
    });

    // Coupon: copy the code (Clipboard API, fallback execCommand), visible + announced "Copied!".
    function copyText(text, done) {
      var fallback = function () {
        var ok = false;
        try {
          var ta = document.createElement('textarea');
          ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;';
          document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
          ok = document.execCommand('copy');
          document.body.removeChild(ta);
        } catch (e) { ok = false; }
        done(ok);
      };
      if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext !== false) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, fallback);
      } else { fallback(); }
    }
    bar.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('.abp-copy') : null;
      if (!btn || !bar.contains(btn)) { return; }
      e.preventDefault();
      var code = btn.getAttribute('data-code') || '';
      if (!/^[A-Z0-9_-]{1,32}$/.test(code)) { return; }
      copyText(code, function (ok) {
        var label = btn.querySelector('.abp-copy-label'), live = btn.parentNode.querySelector('.abp-sr');
        var msg = ok ? (btn.getAttribute('data-copied') || 'Copied!') : code;
        if (ok) {
          btn.classList.add('abp-copied');
          if (label) { label.textContent = btn.getAttribute('data-copied') || 'Copied!'; }
          track(bar, btn.closest('.abp-item'), 'copy');
          clearTimeout(btn.abpT);
          btn.abpT = setTimeout(function () { btn.classList.remove('abp-copied'); if (label) { label.textContent = btn.getAttribute('data-label') || 'Copy'; } }, 2200);
        }
        if (live) { live.textContent = ''; setTimeout(function () { live.textContent = msg; }, 30); }
      });
    });

    // Pause on mouse hover / keyboard focus; a tap on touch screens toggles pause (no stuck mouseenter).
    function pointerIsMouse(e) { return !e.pointerType || e.pointerType === 'mouse'; }
    var touchTimer = null;
    function pause() { paused = true; bar.classList.add('abp-paused'); stopRotate(); }
    function resume() {
      if (touchTimer) { clearTimeout(touchTimer); touchTimer = null; }
      paused = false;
      if (userPaused) { return; } // the pause button wins until it is pressed again
      bar.classList.remove('abp-paused');
      startRotate();
    }
    // Touch: a tap pauses for at most 8 s; a tap anywhere outside the bar resumes at once.
    function touchPause() { pause(); if (touchTimer) { clearTimeout(touchTimer); } touchTimer = setTimeout(resume, 8000); }

    if (!inline) {
      if (window.PointerEvent) {
        bar.addEventListener('pointerenter', function (e) { if (pointerIsMouse(e)) { pause(); } });
        bar.addEventListener('pointerleave', function (e) { if (pointerIsMouse(e)) { resume(); } });
        bar.addEventListener('pointerup', function (e) {
          if (!pointerIsMouse(e) && !(e.target.closest && e.target.closest('a, button, input, label, form'))) { if (paused) { resume(); } else { touchPause(); } }
        });
        document.addEventListener('pointerdown', function (e) { if (paused && touchTimer && !bar.contains(e.target)) { resume(); } }, true);
      } else {
        bar.addEventListener('mouseenter', pause);
        bar.addEventListener('mouseleave', resume);
      }
      bar.addEventListener('focusin', pause);
      bar.addEventListener('focusout', function () { setTimeout(function () { if (!bar.contains(document.activeElement)) { resume(); } }, 0); });
    }

    /* ---------------- Pause / play button (WCAG 2.2.2: moving content can be stopped) ---------------- */
    var pauseBtn = bar.querySelector('.abp-pause');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', function () {
        userPaused = !userPaused;
        var label = bar.getAttribute(userPaused ? 'data-l-play' : 'data-l-pause') || '';
        pauseBtn.setAttribute('aria-pressed', userPaused ? 'true' : 'false');
        if (label) { pauseBtn.setAttribute('aria-label', label); pauseBtn.title = label; }
        bar.classList.toggle('abp-user-paused', userPaused);
        if (userPaused) { pause(); } else { resume(); }
      });
    }

    /* ---------------- Auto-hide: fold into a small tab after N seconds (bars only) ----------------
       Not while the mouse / keyboard focus is on the bar; stays folded for the rest of the visit (sessionStorage
       "abp_min"); the tab (a real button, labelled, aria-expanded) opens it again. */
    var autohide = inline ? 0 : parseInt(bar.getAttribute('data-autohide'), 10) || 0, tab = null, minTimer = null, armed = false;
    function minList() { try { var v = JSON.parse(sessionStorage.getItem('abp_min') || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
    function saveMin(on) {
      try {
        var place = bar.getAttribute('data-place'), list = minList().filter(function (p) { return p !== place; });
        if (on) { list.push(place); }
        sessionStorage.setItem('abp_min', JSON.stringify(list));
      } catch (e) { /* storage blocked */ }
    }
    function makeTab() {
      if (tab || !autohide) { return; }
      tab = document.createElement('button');
      tab.type = 'button';
      tab.className = 'abp-tab abp-tab-' + (isTop ? 'top' : 'bottom') + (isTop && !bar.classList.contains('abp-sticky') ? '' : ' abp-tab-fixed');
      tab.setAttribute('aria-expanded', 'false');
      if (bar.id) { tab.setAttribute('aria-controls', bar.id); }
      tab.setAttribute('aria-label', bar.getAttribute('data-l-show') || 'Show');
      tab.title = bar.getAttribute('data-l-show') || '';
      tab.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M2.5 6.2v3.6h2.2l4.6 3V3.2l-4.6 3H2.5zM11.4 5.4a3.6 3.6 0 0 1 0 5.2M12.9 3.8a5.8 5.8 0 0 1 0 8.4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      tab.hidden = true;
      bar.parentNode.insertBefore(tab, bar.nextSibling);
      tab.addEventListener('click', expand);
    }
    function minimize() {
      if (closed || bar.style.display === 'none') { return; }
      var focusWasInside = bar.contains(document.activeElement);
      makeTab();
      bar.classList.add('abp-min');
      stopRotate();
      fitBody();
      restoreEdges();
      if (tab) { tab.hidden = false; paintBar(items()[index]); }
      saveMin(true);
      if (focusWasInside && tab) { tab.focus(); }
    }
    function expand() {
      bar.classList.remove('abp-min');
      if (tab) { tab.hidden = true; tab.setAttribute('aria-expanded', 'true'); }
      saveMin(false);
      armed = true; // opened by the visitor: not folded again on this page
      relayout();
      var first = bar.querySelector('.abp-item.abp-active a[href], .abp-item.abp-active button, .abp-item.abp-active input, .abp-close');
      if (first) { first.focus(); }
    }
    function armAutohide() {
      if (!autohide || armed || closed || hidden()) { return; }
      armed = true;
      var wait = function () { minTimer = setTimeout(function () { if (paused || userPaused) { wait(); } else { minimize(); } }, autohide * 1000); };
      wait();
    }
    if (autohide && bar.classList.contains('abp-min')) {
      // Folded earlier in this visit (the pre-script added abp-min before the first paint).
      makeTab();
      armed = true;
      tab.hidden = false;
    }

    /* ---------------- Triggers: after a delay, after scrolling, on exit intent ----------------
       Once fired, the message shows at once on the next pages of this visit (sessionStorage "abp_trig"). */
    function fired(el) {
      try {
        var list = JSON.parse(sessionStorage.getItem('abp_trig') || '[]');
        list = Array.isArray(list) ? list : [];
        if (list.indexOf(el.getAttribute('data-id')) === -1) { list.push(el.getAttribute('data-id')); }
        sessionStorage.setItem('abp_trig', JSON.stringify(list.slice(-100)));
      } catch (e) { /* storage blocked: only this page */ }
    }
    function appear(el) {
      if (closed || !el.hasAttribute('data-toff') || !inDoc(el)) { return; }
      var wasHidden = bar.style.display === 'none';
      el.removeAttribute('data-toff');
      fired(el);
      refreshVisible();
      var list = items(), i = list.indexOf(el);
      if (mode === 'rotate' && i > 0) { show(i); startRotate(); }
      if (wasHidden && !hidden() && !reduced) {
        bar.classList.add('abp-enter');
        setTimeout(function () { bar.classList.remove('abp-enter'); }, 700);
      }
    }
    Array.prototype.forEach.call(bar.querySelectorAll('.abp-item[data-trig][data-toff]'), function (el) {
      var t = String(el.getAttribute('data-trig')).split(':'), v = parseInt(t[1], 10) || 0;
      if (t[0] === 'delay') {
        setTimeout(function () { appear(el); }, Math.max(1, v) * 1000);
      } else if (t[0] === 'scroll') {
        var onScroll = function () {
          var room = document.documentElement.scrollHeight - window.innerHeight, pct = room > 0 ? (window.pageYOffset || document.documentElement.scrollTop) * 100 / room : 100;
          if (pct >= v) { window.removeEventListener('scroll', onScroll); appear(el); }
        };
        window.addEventListener('scroll', onScroll, { passive: true });
        setTimeout(onScroll, 400);
      } else if (t[0] === 'exit' && window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
        // Exit intent: the mouse leaves the window through the top edge (desktop only).
        var onOut = function (e) { if (!e.relatedTarget && e.clientY <= 0) { document.removeEventListener('mouseout', onOut); appear(el); } };
        setTimeout(function () { document.addEventListener('mouseout', onOut); }, 1500);
      }
    });

    var resizeTimer = null;
    window.addEventListener('resize', function () {
      if (!inDoc(bar)) { return; }
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(relayout, 200);
    });

    // While scrolling only the cached elements are updated; the page is re-scanned at most once a second
    // (headers that become fixed only after scrolling).
    if (!inline) {
      var edgeQueued = false, scanTimer = null;
      window.addEventListener('scroll', function () {
        if (edgeQueued) { return; }
        edgeQueued = true;
        window.requestAnimationFrame(function () {
          edgeQueued = false;
          var wait = 1000 - (Date.now() - lastScan);
          if (wait <= 0) { rescan(); } else if (!scanTimer) {
            scanTimer = setTimeout(function () { scanTimer = null; rescan(); adaptEdges(); }, wait);
          }
          adaptEdges();
        });
      }, { passive: true });
    }

    // Clicks on the button, the whole-message link or a link inside the text (not the privacy link of a form).
    bar.addEventListener('click', function (e) {
      var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
      if (a && bar.contains(a) && !a.closest('.abp-form')) { track(bar, a.closest('.abp-item'), 'click'); }
    });

    // Crossing the 768 px breakpoint (rotation, resize): rebuild from the messages meant for this screen size.
    if (mq) {
      var onMq = function () { if (inDoc(bar)) { refreshVisible(); } };
      if (mq.addEventListener) { mq.addEventListener('change', onMq); } else if (mq.addListener) { mq.addListener(onMq); }
    }

    applySchedule();
    tick();
    if (!items().length) {
      deviceHidden = true;
      hideBar();
    } else {
      bar.style.display = '';
    }
    startTick();
    // Custom colours: paint the styles now (no wait); Automatic colours need the theme's final CSS (load).
    if (bar.getAttribute('data-color') !== 'auto') { applyAutoColours(); }
    relayout();
    armAutohide();

    var api = {
      bar: bar,
      refresh: refreshVisible,
      trackShown: trackShown,
      relayout: function () { checkIcons(); stabilise(); fitBody(); startTick(); if (mode === 'marquee') { startMarquee(); } },
      afterLoad: function () { checkIcons(); applyAutoColours(); relayout(); }
    };
    bar.abpApi = api;
    instances.push(api);
    if (loaded) { api.afterLoad(); }
  }

  /* ---------------- Free shipping, goals and cart conditions ----------------
     After OpenCart's own AJAX cart requests (add / remove / update, both versions) the amounts are fetched from a
     small read-only endpoint (same-origin GET, JSON) and every bar and box is updated in place. */
  var cartTimer = null, cartBusy = false, cartAgain = false;
  function cartItems() { return document.querySelectorAll('.abp .abp-item[data-fs="1"], .abp .abp-item[data-cc="1"]'); }
  function refreshCart() {
    var holder = document.querySelector('.abp[data-cart]'), url = holder ? holder.getAttribute('data-cart') : '';
    var ids = [];
    Array.prototype.forEach.call(cartItems(), function (el) { var id = el.getAttribute('data-id'); if (/^\d+$/.test(id) && ids.indexOf(id) === -1) { ids.push(id); } });
    if (cartBusy) { cartAgain = true; return; } // a change during a refresh: refresh once more afterwards
    if (!url || !ids.length || !window.fetch) { return; }
    cartBusy = true;
    window.fetch(url + (url.indexOf('?') === -1 ? '?' : '&') + 'ids=' + ids.slice(0, 20).join(','), { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (json) {
        cartBusy = false;
        if (cartAgain) { cartAgain = false; queueCart(); }
        if (!json || typeof json.m !== 'object' || !json.m) { return; }
        var touched = [];
        Array.prototype.forEach.call(cartItems(), function (el) {
          var row = json.m[String(parseInt(el.getAttribute('data-id'), 10))], bar = el.closest('.abp');
          if (!row || typeof row !== 'object') {
            // The cart conditions no longer hold (the server left the message out).
            if (el.getAttribute('data-cc') === '1' && !el.hasAttribute('data-coff')) { el.setAttribute('data-coff', '1'); touched.push(bar); }
            return;
          }
          ['a', 'b'].forEach(function (v) {
            var txt = el.querySelector('.abp-v-' + v + ' .abp-txt');
            if (txt && typeof row[v] === 'string') { txt.innerHTML = row[v]; } // server-sanitized HTML
          });
          var fill = el.querySelector('.abp-progress-fill'), p = Math.max(0, Math.min(100, parseFloat(row.p) || 0));
          if (fill) { fill.style.width = p + '%'; }
          var prog = el.querySelector('.abp-progress');
          if (prog) {
            prog.setAttribute('data-p', String(Math.round(p)));
            var k = parseInt(row.k, 10) || 0;
            Array.prototype.forEach.call(prog.querySelectorAll('.abp-step'), function (s, i) { s.classList.toggle('abp-step-done', i < k); });
            if (prog.hasAttribute('data-k')) { prog.setAttribute('data-k', String(k)); }
          }
          if (row.done) { el.setAttribute('data-done', '1'); } else { el.removeAttribute('data-done'); }
          if (el.getAttribute('data-cc') === '1' && (!!row.off) !== el.hasAttribute('data-coff')) {
            if (row.off) { el.setAttribute('data-coff', '1'); } else { el.removeAttribute('data-coff'); }
            touched.push(bar);
          }
          if (touched.indexOf(bar) === -1) { touched.push(bar); }
        });
        touched.forEach(function (bar) {
          if (bar && bar.abpApi) { if (bar.style.display === 'none' || bar.querySelector('.abp-item[data-coff], .abp-item[data-cc]')) { bar.abpApi.refresh(); } bar.abpApi.relayout(); }
        });
      })
      .catch(function () { cartBusy = false; if (cartAgain) { cartAgain = false; queueCart(); } });
  }
  function queueCart() { clearTimeout(cartTimer); cartTimer = setTimeout(refreshCart, 300); }

  /* ---------------- Cloudflare Turnstile (optional anti-bot check of the sign-up form) ----------------
     Only when the shop entered its own keys: the form then carries data-ts (site key) and a .abp-ts box. Cloudflare's
     script is loaded once, only on pages with such a form, and — with "wait for cookie consent" — only after consent
     (until then the box shows data-ts-wait). The widget puts its token into the form ("cf-turnstile-response"); the
     shop checks it with Cloudflare. A token is used once: after every answer of the shop the widget is reset. */
  var tsState = 0, tsWait = [];
  function tsReady() {
    tsState = 2;
    var q = tsWait;
    tsWait = [];
    q.forEach(function (fn) { try { fn(); } catch (e) { /* one form must not stop the others */ } });
  }
  function tsLoad(fn) {
    if (tsState === 2 && window.turnstile) { fn(); return; }
    tsWait.push(fn);
    if (tsState) { return; }
    tsState = 1;
    window.abpTsReady = tsReady;
    var s = document.createElement('script');
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=abpTsReady';
    s.async = true;
    s.onerror = function () {
      tsState = 0;
      tsWait = [];
      Array.prototype.forEach.call(document.querySelectorAll('.abp-form[data-ts]'), function (f) { f.abpTs = undefined; var b = f.querySelector('.abp-ts'); if (b) { b.textContent = f.getAttribute('data-err-ts') || ''; } });
    };
    (document.head || document.documentElement).appendChild(s);
  }
  function tsStart(form) {
    var box = form && form.querySelector ? form.querySelector('.abp-ts') : null;
    if (!box || form.abpTs !== undefined || !inDoc(form)) { return; }
    if (waitConsent()) { box.textContent = form.getAttribute('data-ts-wait') || ''; return; }
    form.abpTs = null;
    box.textContent = '';
    tsLoad(function () {
      if (!inDoc(form) || !window.turnstile) { return; }
      try {
        form.abpTs = window.turnstile.render(box, {
          sitekey: form.getAttribute('data-ts'),
          action: 'abp-signup',
          appearance: 'interaction-only',
          'refresh-expired': 'auto'
        });
      } catch (e) {
        form.abpTs = undefined;
        box.textContent = form.getAttribute('data-err-ts') || '';
      }
    });
  }
  function tsForms() { Array.prototype.forEach.call(document.querySelectorAll('.abp-form[data-ts]'), tsStart); }
  function tsReset(form) { try { if (form.abpTs && window.turnstile) { window.turnstile.reset(form.abpTs); } } catch (e) { /* a new token comes with the next try */ } }

  /* ---------------- E-mail sign-up (newsletter, double opt-in) ----------------
     Checked here first (address, consent box, anti-bot token when on), then sent with the page's form token; the
     answer replaces the form. */
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || !form.classList || !form.classList.contains('abp-form')) { return; }
    e.preventDefault();
    var email = form.querySelector('.abp-email'), consent = form.querySelector('input[name="consent"]'), msg = form.querySelector('.abp-form-msg');
    var btn = form.querySelector('.abp-submit'), item = form.closest('.abp-item'), bar = form.closest('.abp');
    var say = function (text, field) {
      form.classList.toggle('abp-form-error', !!field);
      if (email) { email.setAttribute('aria-invalid', field === 'email' ? 'true' : 'false'); }
      if (consent) { consent.setAttribute('aria-invalid', field === 'consent' ? 'true' : 'false'); }
      if (msg) { msg.textContent = ''; setTimeout(function () { msg.textContent = text || ''; }, 30); }
      if (field === 'email' && email) { email.focus(); } else if (field === 'consent' && consent) { consent.focus(); }
    };
    var value = email ? email.value.trim() : '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) || value.length > 96) { say(form.getAttribute('data-err-email'), 'email'); return; }
    if (!consent || !consent.checked) { say(form.getAttribute('data-err-consent'), 'consent'); return; }
    if (form.hasAttribute('data-ts')) {
      var tsv = form.querySelector('[name="cf-turnstile-response"]');
      if (!tsv || !tsv.value) { tsStart(form); say(waitConsent() ? form.getAttribute('data-ts-wait') : form.getAttribute('data-err-ts'), 'form'); return; }
    }
    if (form.abpBusy || !window.fetch || !window.FormData) { return; }
    form.abpBusy = true;
    if (btn) { btn.disabled = true; }
    say(form.getAttribute('data-sending'), '');
    var fd = new FormData(form);
    fd.set('email', value);
    fd.append('tok', form.getAttribute('data-tok') || '');
    fd.append('id', item ? item.getAttribute('data-id') : '');
    window.fetch(form.getAttribute('action'), { method: 'POST', body: fd, credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        form.abpBusy = false;
        if (btn) { btn.disabled = false; }
        if (j && j.ok) {
          var done = document.createElement('span');
          done.className = 'abp-form-done';
          done.setAttribute('role', 'status');
          done.tabIndex = -1;
          done.textContent = j.msg || form.getAttribute('data-success') || '';
          form.parentNode.replaceChild(done, form);
          done.focus();
          ga(bar, item, 'abp_subscribe');
          if (bar && bar.abpApi) { bar.abpApi.relayout(); }
        } else {
          tsReset(form);
          say((j && j.error) || form.getAttribute('data-err-failed'), (j && j.field) || 'form');
        }
      })
      .catch(function () {
        form.abpBusy = false;
        if (btn) { btn.disabled = false; }
        tsReset(form);
        say(form.getAttribute('data-err-failed'), 'form');
      });
  }, true);

  /* ---------------- Start ---------------- */
  var loaded = false; // set by afterLoad(); boxes started later (mini-cart reload) run their load step at once
  function scan() {
    try { if (window.abpPre) { window.abpPre(); } } catch (e) { /* boxes still start without it */ }
    Array.prototype.forEach.call(document.querySelectorAll('.abp[data-abp], #abp-bar'), function (bar) {
      try { init(bar); } catch (e) { /* one broken box must not stop the others */ }
    });
    tsForms();
  }
  var hooked = false;
  function hookAjax() {
    if (hooked || !window.jQuery) { return; }
    hooked = true;
    window.jQuery(document).ajaxComplete(function (e, xhr, settings) {
      var url = settings && typeof settings.url === 'string' ? settings.url : '';
      if (/route=(checkout|common)(\/|%2F)cart|(checkout|common)\/cart[\/.|]/i.test(url)) {
        queueCart();
        setTimeout(scan, 60); // the mini-cart drop-down is reloaded with a new box
      }
    });
  }

  /* "Wait for cookie consent": the shop's consent tool sets window.abpConsent = true and fires "abp:consent" (on
     document or window). Then A/B variants and visitor rules are decided, and the messages on screen are counted.
     Without the event the value is checked again at load and on every statistics call. */
  var consentSeen = false;
  function consentGiven() {
    if (consentSeen || window.abpConsent !== true || !document.querySelector('.abp[data-consent="1"]')) { return; }
    consentSeen = true;
    try { if (window.abpPre && window.abpPre.consent) { window.abpPre.consent(); } } catch (e) { /* bars keep working */ }
    tsForms();
    instances.forEach(function (api) {
      try { if (inDoc(api.bar)) { api.refresh(); api.trackShown(); } } catch (e2) { /* one broken box must not stop the others */ }
    });
  }
  document.addEventListener('abp:consent', consentGiven);
  window.addEventListener('abp:consent', consentGiven);

  window.AnnouncementBarPro = { scan: scan, refreshCart: queueCart, consent: consentGiven };

  function start() {
    scan();
    hookAjax();
  }
  // Web fonts, icons and theme colours are final only after load.
  function afterLoad() { loaded = true; hookAjax(); instances.forEach(function (api) { if (inDoc(api.bar)) { api.afterLoad(); } }); consentGiven(); }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', start); } else { start(); }
  if (document.readyState === 'complete') { afterLoad(); } else { window.addEventListener('load', afterLoad); }
  // Back/forward cache: the cart may have changed on another page.
  window.addEventListener('pageshow', function (e) { if (e.persisted) { queueCart(); } });
})();

(function () {
/* Announcement Bar Pro Embed — core (no DOM): config checks, HTML allow-list, URL / CSS filters, page rules,
   time zones, free-shipping goal. Pure functions, also loaded by the unit tests (node) and the Configurator. */
var ABPCore = (function () {
  'use strict';

  var str = function (v, max) { v = typeof v === 'string' ? v : (typeof v === 'number' ? String(v) : ''); return max ? v.slice(0, max) : v; };
  function clamp(v, min, max, def) { v = parseInt(v, 10); return isNaN(v) ? def : Math.max(min, Math.min(max, v)); }
  function oneOf(v, list) { return list.indexOf(v) !== -1 ? v : list[0]; }

  /* ---------------- HTML allow-list (port of the PHP Sanitizer) ----------------
     Result is a small tree, never an HTML string: text = string, element = {t, c[]} (+ href / blank for links).
     Allowed: b strong i em u s br span a[href, target=_blank]. Script-like tags go with their content; every
     other tag is unwrapped (its text stays). Links need an http(s) / relative URL and cannot nest. */
  var ALLOWED = { b: 1, strong: 1, i: 1, em: 1, u: 1, s: 1, br: 1, span: 1, a: 1 };
  // Removed together with everything up to their end tag. Any other tag that is not allowed is unwrapped (its text
  // stays; void tags such as img / input / meta have no text, so they simply disappear).
  var DROP = {}, ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0' };
  'script style textarea title noscript iframe xmp noembed noframes plaintext object template select head'.split(' ').forEach(function (t) { DROP[t] = 1; });

  function decode(s) {
    return String(s).replace(/&(#x[0-9a-f]{1,6}|#\d{1,7}|[a-z]{2,8});/gi, function (m, e) {
      if (e.charAt(0) === '#') {
        var n = e.charAt(1).toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
        return n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : '\ufffd';
      }
      return ENT[e.toLowerCase()] || m; // only the six names above (2-8 letters: never a prototype key)
    });
  }
  function attrs(s) {
    var out = {}, re = /([^\s"'>\/=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g, m;
    while ((m = re.exec(s))) { var k = m[1].toLowerCase(); if (out[k] === undefined) { out[k] = decode(m[2] !== undefined ? m[2] : m[3] !== undefined ? m[3] : m[4] || ''); } }
    return out;
  }
  function pushText(list, t) { if (!t) { return; } if (typeof list[list.length - 1] === 'string') { list[list.length - 1] += t; } else { list.push(t); } }

  function parseHtml(html) {
    html = String(html).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
    var root = { n: '#root', c: [] }, stack = [root], i = 0, len = html.length;
    while (i < len) {
      var lt = html.indexOf('<', i), top = stack[stack.length - 1];
      if (lt === -1) { pushText(top.c, decode(html.slice(i))); break; }
      pushText(top.c, decode(html.slice(i, lt)));
      i = lt;
      var rest = html.slice(i), m;
      if (/^<!-{2}/.test(rest)) { var e = html.indexOf('-->', i + 4); i = e === -1 ? len : e + 3; continue; }
      if (/^<[!?]/.test(rest) || /^<\/[^a-zA-Z>]/.test(rest)) { var g = html.indexOf('>', i); i = g === -1 ? len : g + 1; continue; }
      m = /^<(\/?)([a-zA-Z][a-zA-Z0-9-]*)((?:[^>"']|"[^"]*"|'[^']*')*)>/.exec(rest);
      if (!m) { pushText(top.c, '<'); i++; continue; } // "x < 5" is text
      i += m[0].length;
      var name = m[2].toLowerCase();
      if (m[1]) { // closing tag: close the nearest open element of that name, if any
        for (var s = stack.length - 1; s > 0; s--) { if (stack[s].n === name) { stack.length = s; break; } }
        continue;
      }
      if (DROP[name]) {
        var close = new RegExp('</' + name + '\\s*>', 'i').exec(html.slice(i));
        i = close ? i + close.index + close[0].length : len;
        continue;
      }
      if (name === 'br') { top.c.push({ t: 'br', c: [] }); continue; }
      var node = { n: name, t: ALLOWED[name] ? name : '#', c: [] };
      if (name === 'a') { var a = attrs(m[3]); node.href = url(a.href); if (a.target === '_blank') { node.blank = 1; } if (!node.href) { node.t = '#'; } }
      top.c.push(node);
      stack.push(node);
    }
    return root.c; // '#' = unwrapped tag (children kept); a link inside a link is unwrapped when the DOM is built
  }
  // Text of a message: allow-listed HTML, or the literal text (plain mode).
  function rich(text, allowHtml) { text = str(text, 2000); return allowHtml ? parseHtml(text) : (text ? [text] : []); }
  function plainOf(nodes) { return nodes.map(function (n) { return typeof n === 'string' ? n : n.t === 'br' ? ' ' : n.v || plainOf(n.c); }).join(''); }
  function isBlank(nodes) { return !/\S/.test(plainOf(nodes)) && !nodes.some(function (n) { return n.t === 'cd'; }); }
  // Replaces the first {token} in text with node(s), removes the rest. Returns true when replaced.
  function replaceToken(nodes, token, repl) {
    var done = false;
    (function walk(list) {
      for (var i = 0; i < list.length; i++) {
        var n = list[i];
        if (typeof n !== 'string') { walk(n.c); continue; }
        if (n.indexOf(token) === -1) { continue; }
        var parts = n.split(token), out = [parts[0]];
        for (var p = 1; p < parts.length; p++) { if (!done && repl) { out.push(repl); done = true; } out.push(parts[p]); }
        out = out.filter(function (x) { return x !== ''; });
        list.splice.apply(list, [i, 1].concat(out));
        i += out.length - 1;
      }
    })(nodes);
    return done;
  }
  function copyNodes(nodes) { return JSON.parse(JSON.stringify(nodes)); }

  /* ---------------- URLs, colours, CSS ---------------- */
  // http(s) absolute, or relative ("/x", "x.html", "?a=b", "#top"); never "//host", "javascript:", "data:".
  function url(v) {
    v = str(v).replace(/[\r\n\t\0]/g, '').trim().replace(/ /g, '%20');
    v = v.replace(/[^\x00-\x7F]+/g, function (m) { try { return encodeURIComponent(m); } catch (e) { return ''; } });
    if (!v || v.length > 500 || !/^[A-Za-z0-9\-._~:\/?#\[\]@!$&()*+,;=%]+$/.test(v)) { return ''; }
    if (/^https?:\/\/[A-Za-z0-9.-]+(:\d{1,5})?([\/?#]|$)/i.test(v)) { return v; }
    if (/^\/\//.test(v) || /^[^\/?#]*:/.test(v)) { return ''; } // protocol-relative or any other scheme
    return v;
  }
  function color(v, def) { return /^#[0-9a-f]{6}$/i.test(str(v)) ? v.toLowerCase() : def; }
  // Custom CSS, safe inside <style>: port of Features::css(). (No literal HTML comment opener in this file: it is
  // inlined into <script> elements.)
  function css(v) {
    var c = str(v).replace(/\0/g, '').slice(0, 10000), before;
    c = c.replace(/<!-{2}|-{2}>|<\/?[a-z!][^>]*>?/gi, '').replace(/[<\\]/g, '');
    do {
      before = c;
      c = c.replace(/@(import|charset|namespace)\b[^;{}]*;?/gi, '')
        .replace(/(javascript|vbscript|livescript)\s*:/gi, '')
        .replace(/(expression|behaviou?r|-moz-binding)\s*[:(]?/gi, '')
        .replace(/url\s*\(\s*(['"]?)([\s\S]*?)\1\s*\)/gi, function (m, q, u) {
          u = u.trim();
          return /^(https?:\/\/|\/(?!\/)|data:image\/(png|gif|jpe?g|webp|svg\+xml)[;,])/i.test(u) && !/['"()\s]/.test(u) ? 'url("' + u + '")' : 'none';
        });
    } while (c !== before);
    return c.trim();
  }
  function coupon(v) { v = str(v).trim().toUpperCase(); return /^[A-Z0-9_-]{1,32}$/.test(v) ? v : ''; }
  function clock(v) { var m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(str(v)); return m ? m[0] : ''; }
  function weekdays(v) { var out = '1234567'.replace(/\d/g, function (d) { return String(v).indexOf(d) !== -1 ? d : ''; }); return out.length === 7 ? '' : out; }
  function words(v, max) { return str(v, 500).toLowerCase().split(',').map(function (s) { return s.trim(); }).filter(Boolean).slice(0, max || 20); }

  /* ---------------- Time zones and schedules ---------------- */
  // Offset (seconds east of UTC) of an IANA zone at a moment; the browser's own zone when unknown.
  function tzOffset(tz, ms) {
    try {
      var p = {};
      new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
        .formatToParts(new Date(ms)).forEach(function (x) { p[x.type] = parseInt(x.value, 10); });
      return Math.round((Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) - Math.floor(ms / 1000) * 1000) / 1000);
    } catch (e) { return -new Date(ms).getTimezoneOffset() * 60; }
  }
  // "2026-11-30T23:59" (a date only: 00:00, or 23:59 for an end) in the site's zone → Unix ms; 0 when empty / invalid.
  function zoned(v, tz, endOfDay) {
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?$/.exec(str(v).trim());
    if (!m) { return 0; }
    var guess = Date.UTC(+m[1], +m[2] - 1, +m[3], m[4] ? +m[4] : endOfDay ? 23 : 0, m[5] ? +m[5] : endOfDay ? 59 : 0);
    return guess - tzOffset(tz, guess - tzOffset(tz, guess) * 1000) * 1000;
  }
  // Recurring cut-off rule for the storefront script: "d|14:00|67" (daily, not Sat/Sun) or "w|14:00|5" (Fridays).
  function recurRule(m) {
    var t = clock(m.recur_time);
    if (!t) { return ''; }
    if (m.recur === 'daily') { return 'd|' + t + '|' + weekdays(m.recur_skip || []).replace(/^$/, ''); }
    return m.recur === 'weekly' ? 'w|' + t + '|' + clamp(m.recur_day, 1, 7, 5) : '';
  }

  /* ---------------- Pages and language ---------------- */
  // Rule types (path + query of the page, no host, case-insensitive): contains, equals (path; a trailing slash does not
  // matter), wildcard ("*" = anything, everything else literal). Wildcards are matched without regular expressions
  // (linear backtracking only), so no rule can hang the page.
  function glob(p, s) {
    var i = 0, j = 0, star = -1, mark = 0;
    while (j < s.length) {
      if (p[i] === '*') { star = i++; mark = j; } else if (i < p.length && p[i] === s[j]) { i++; j++; } else if (star < 0) { return false; } else { i = star + 1; j = ++mark; }
    }
    while (p[i] === '*') { i++; }
    return i === p.length;
  }
  function pageRule(rule, loc) {
    var v = str(rule && rule.value, 300).trim().toLowerCase(), path = String(loc.pathname || '/').toLowerCase(), full = path + String(loc.search || '').toLowerCase();
    var norm = function (x) { return x.length > 1 ? x.replace(/\/+$/, '') : x; };
    if (!v) { return false; }
    if (rule.type === 'equals') { return norm(v) === norm(path) || v === full; }
    if (rule.type === 'wildcard') { return glob(v, full); }
    return full.indexOf(v) !== -1;
  }
  function pagesOk(pages, loc) {
    if (!pages || pages.mode === 'all' || !pages.rules.length) { return true; }
    var hit = pages.rules.some(function (r) { return pageRule(r, loc); });
    return pages.mode === 'exclude' ? !hit : hit;
  }
  // Language of the page: the first URL segment (/lv/...), ?lang=lv, then <html lang>; only languages of the config count.
  function pageLang(htmlLang, loc, langs, def) {
    var ok = function (l) { l = String(l || '').toLowerCase().split(/[-_]/)[0]; return langs.indexOf(l) !== -1 ? l : ''; };
    return ok((/^\/([a-z]{2})(?:[-_][a-z]{2})?(?:\/|$)/i.exec(loc.pathname || '') || [])[1]) || ok((/[?&]lang=([a-z]{2})\b/i.exec(loc.search || '') || [])[1]) || ok(htmlLang) || def;
  }
  function pick(v, lang, def) {
    if (typeof v === 'string') { return v; }
    if (!v || typeof v !== 'object') { return ''; }
    return str(v[lang] || v[def]); // lang / def are checked two-letter codes
  }

  /* ---------------- Free-shipping goal (cart from the page's adapter) ---------------- */
  function money(amount, cur, lang) {
    try { return new Intl.NumberFormat(lang || 'en', { style: 'currency', currency: cur }).format(amount); } catch (e) { return amount.toFixed(2) + ' ' + cur; }
  }
  // Amount for the cart's currency: a number (in settings.currency) or {"EUR": 50, "USD": 60}. Never converted.
  // Returns null when it cannot show (no cart yet, no amount for this currency).
  function goal(threshold, cart, base, lang) {
    if (!cart) { return null; }
    var sub = +cart.subtotal || 0, cur = String(cart.currency || base).toUpperCase();
    var amt = typeof threshold === 'object' ? +threshold[cur] || 0 : cur === base ? +threshold || 0 : 0;
    return amt > 0 ? { done: sub >= amt, pct: Math.min(100, Math.floor(sub * 100 / amt)), remaining: money(Math.max(0, amt - sub), cur, lang) } : null;
  }

  // 12 hex characters (dismiss key: a visible change shows a closed message again).
  function hash12(s) {
    var a = 0x811c9dc5, b = 5381;
    for (var i = 0; i < s.length; i++) { a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; b = (Math.imul(b, 33) + s.charCodeAt(i)) >>> 0; }
    return ('0000000' + a.toString(16)).slice(-8) + ('000' + (b & 0xffff).toString(16)).slice(-4);
  }

  /* ---------------- Config ---------------- */
  var LABELS = { label: 'Announcement', close: 'Close', days: 'd', copy: 'Copy', copied: 'Copied!', copy_code: 'Copy code %s', prev: 'Previous message', next: 'Next message', show: 'Show announcements', pause: 'Pause messages', play: 'Play messages' };
  var FONTS = '|system|humanist|geometric|serif|mono|rounded';
  /* Config schema: "key:kind:arg". Kinds: e = one of (first is the default), n = integer min|max|default, t = true unless
     false, f = false unless true, x = text or {lang: text}, u = URL, k = HH:MM, w = weekdays, c = colour, s = string (max
     length), l = comma list (lower case). Anything else in the JSON is ignored. */
  var SETTINGS = 'position:e:top|bottom,mode:e:rotate|marquee|stack,transition:e:fade|slide,interval:n:2|60|5,speed:n:20|300|60,font_size:n:10|30|14,' +
    'padding:n:0|30|8,sticky:t,arrows:t,dismissible:t,dismiss_days:n:0|365|1,pause_button:t,autohide:n:0|600|0,max_messages:n:0|20|0,' +
    'color_mode:e:custom|auto,font:e:' + FONTS + ',ga4:f,consent_wait:f,allow_html:t';
  var MESSAGE = 'enabled:t,priority:n:0|100|0,placement:e:|top|bottom,type:e:standard|free_shipping,text:x,mobile_text:x,link:u,link_text:x,' +
    'new_tab:f,button_style:e:outline|filled|link,bg_color:c:#222222,text_color:c:#ffffff,style:e:solid|gradient|soft|minimal|glass,' +
    'font:e:' + FONTS + ',image:u,overlay:n:0|90|55,countdown:f,date_start:s:20,date_end:s:20,recur:e:|daily|weekly,recur_time:k,' +
    'recur_day:n:1|7|5,recur_skip:w,weekdays:w,time_start:k,time_end:k,device:e:all|desktop|mobile,utm_source:l,utm_medium:l,' +
    'utm_campaign:l,referrer:l,visitor:e:all|new|returning,trigger:e:none|delay|scroll|exit,success_text:x,progress_bar:t';
  function schema(def, src) {
    var o = {};
    def.split(',').forEach(function (d) {
      d = d.split(':');
      var k = d[0], a = (d[2] || '').split('|'), v = src[k];
      var t = d[1];
      o[k] = t === 'e' ? oneOf(v, a) : t === 'n' ? clamp(v, +a[0], +a[1], +a[2]) : t === 't' ? v !== false : t === 'f' ? v === true : t === 'x' ? texts(v) :
        t === 'u' ? url(v) : t === 'k' ? clock(v) : t === 'w' ? weekdays(v || '') : t === 'c' ? color(v, a[0]) : t === 's' ? str(v, +a[0]).trim() : words(v).join(',');
    });
    return o;
  }
  function normalize(cfg) {
    cfg = cfg && typeof cfg === 'object' ? cfg : {};
    var s = cfg.settings && typeof cfg.settings === 'object' ? cfg.settings : {}, set = schema(SETTINGS, s);
    var langs = (Array.isArray(s.languages) ? s.languages : []).map(function (l) { return str(l).toLowerCase(); }).filter(function (l) { return /^[a-z]{2}$/.test(l); }).slice(0, 30);
    var def = /^[a-z]{2}$/.test(str(s.default_language)) ? s.default_language : langs[0] || 'en';
    if (langs.indexOf(def) === -1) { langs.unshift(def); }
    set.languages = langs; set.default_language = def; set.labels = s.labels && typeof s.labels === 'object' ? s.labels : {}; // strings checked when used
    set.custom_css = css(s.custom_css); set.currency = /^[A-Z]{3}$/.test(str(s.currency)) ? s.currency : 'EUR';
    set.timezone = /^[A-Za-z][\w+\/-]{1,40}$/.test(str(s.timezone)) ? s.timezone : ''; // unknown zone: the visitor's own
    return { version: 1, settings: set, messages: (Array.isArray(cfg.messages) ? cfg.messages : []).slice(0, 100).map(message).filter(Boolean) };
  }
  function texts(v) {
    if (typeof v === 'string') { return str(v, 2000); }
    var o = {};
    if (v && typeof v === 'object') { Object.keys(v).forEach(function (k) { if (/^[a-z]{2}$/.test(k)) { o[k] = str(v[k], 2000); } }); }
    return o;
  }
  function message(m, i) {
    if (!m || typeof m !== 'object') { return null; }
    var o = schema(MESSAGE, m), p = m.pages && typeof m.pages === 'object' ? m.pages : {}, t = m.threshold;
    o.id = clamp(m.id, 1, 999999, i + 1);
    o.icon = str(m.icon, 16).replace(/[<>&"'\\]/g, '').trim();
    o.trigger_value = o.trigger === 'scroll' ? clamp(m.trigger_value, 1, 100, 50) : clamp(m.trigger_value, 1, 600, 5);
    o.referrer = o.referrer.split(',').map(function (h) { return h.replace(/^(https?:\/\/)?(www\.)?/, '').split(/[\/:?#]/)[0]; }).join(',');
    o.coupon = coupon(m.coupon);
    o.languages = (Array.isArray(m.languages) ? m.languages : []).filter(function (l) { return /^[a-z]{2}$/.test(l); });
    o.pages = { mode: oneOf(p.mode, ['all', 'include', 'exclude']), rules: (Array.isArray(p.rules) ? p.rules : []).slice(0, 50).map(function (r) {
      return { type: oneOf(r && r.type, ['contains', 'equals', 'wildcard']), value: str(r && r.value, 300).trim() };
    }).filter(function (r) { return r.value; }) };
    o.threshold = {};
    if (t && typeof t === 'object') { Object.keys(t).forEach(function (k) { if (/^[A-Z]{3}$/.test(k) && +t[k] > 0) { o.threshold[k] = +t[k]; } }); } else { o.threshold = +t > 0 ? +t : 0; }
    if (o.time_start === o.time_end || !o.time_start || !o.time_end) { o.time_start = o.time_end = ''; }
    return o;
  }

  /* ---------------- What to show on this page ----------------
     ctx: {now, lang, loc, cart}. Returns {top: [item], bottom: [item]}; items carry plain data only (text as node
     trees), the DOM is built by the runtime. Device, weekly schedule, campaign, visitor, triggers and the next recurring
     cut-off are decided in the browser by the shared storefront scripts (data-* attributes), as in every other edition. */
  function variantOf(m, lang, def, allowHtml, g, end, recur) {
    var html = rich(pick(m.text, lang, def), allowHtml), html_m = rich(pick(m.mobile_text, lang, def), allowHtml);
    if (isBlank(html_m)) { html_m = []; }
    var seen = JSON.stringify(html) + (html_m.length ? '|m|' + JSON.stringify(html_m) : '');
    if (g) {
      var success = g.done ? rich(pick(m.success_text, lang, def), allowHtml) : [];
      if (!isBlank(success)) { html = success; html_m = []; } else {
        replaceToken(html, '{remaining}', g.remaining && { t: 'rem', v: g.remaining, c: [] });
        replaceToken(html_m, '{remaining}', g.remaining && { t: 'rem', v: g.remaining, c: [] });
      }
    }
    var cd = end || recur ? { t: 'cd', end: end, recur: recur, c: [] } : null;
    var rep = replaceToken(html, '{countdown}', cd), repM = html_m.length ? replaceToken(html_m, '{countdown}', cd && copyNodes(cd)) : false;
    if (isBlank(html) && isBlank(html_m) && !cd) { return null; }
    if (cd && !rep) { html.push(' ', copyNodes(cd)); }
    if (cd && html_m.length && !repM) { html_m.push(' ', copyNodes(cd)); }
    return { d: html, m: html_m, seen: seen, link_text: pick(m.link_text, lang, def).replace(/\s+/g, ' ').trim().slice(0, 80) };
  }

  function select(cfg, ctx) {
    var s = cfg.settings, out = { top: [], bottom: [] }, lang = ctx.lang, def = s.default_language;
    cfg.messages.forEach(function (m, order) {
      if (!m.enabled || (m.languages.length && m.languages.indexOf(lang) === -1) || !pagesOk(m.pages, ctx.loc)) { return; }
      var start = zoned(m.date_start, s.timezone, false), end = zoned(m.date_end, s.timezone, true);
      if ((start && start > ctx.now) || (end && end <= ctx.now)) { return; }
      var fs = m.type === 'free_shipping', g = fs ? goal(m.threshold, ctx.cart, s.currency, lang) : null;
      // A recurring countdown gets its next cut-off from the storefront script (data-recur, site time zone).
      var recur = m.countdown && m.recur ? recurRule(m) : '';
      var v = variantOf(m, lang, def, s.allow_html, g || (fs ? { remaining: '' } : null), m.countdown && !recur ? end : 0, recur);
      if (!v) { return; }
      var seen = v.seen + (m.coupon ? '|c|' + m.coupon : '') + (fs ? '|fs|' + JSON.stringify(m.threshold) + '|' + pick(m.success_text, lang, def) : '') + (m.image ? '|i|' + m.image : '');
      v.wrap = !!m.link && !v.link_text && !hasLink(v.d) && !hasLink(v.m);
      // The item: the cleaned message (m) + what this page view adds.
      out[m.placement || s.position].push({
        m: m, id: m.id, order: order, key: hash12(m.id + '|' + seen + '|' + v.link_text + '|' + m.link + '|' + m.icon + '|' + lang), v: v, end: end, fs: fs, goal: g,
        utm: m.utm_source || m.utm_medium || m.utm_campaign || m.referrer ? JSON.stringify({ s: words(m.utm_source), m: words(m.utm_medium), c: words(m.utm_campaign), r: words(m.referrer) }) : '',
        trig: m.trigger === 'delay' || m.trigger === 'scroll' ? m.trigger + ':' + m.trigger_value : m.trigger === 'exit' ? 'exit' : ''
      });
    });
    ['top', 'bottom'].forEach(function (p) { out[p].sort(function (a, b) { return b.m.priority - a.m.priority || a.order - b.order; }); });
    return out;
  }
  function hasLink(nodes) { return nodes.some(function (n) { return typeof n !== 'string' && (n.t === 'a' || hasLink(n.c)); }); }

  return {
    parseHtml: parseHtml, rich: rich, plainOf: plainOf, replaceToken: replaceToken, decode: decode, url: url, color: color, css: css, coupon: coupon,
    clock: clock, weekdays: weekdays, tzOffset: tzOffset, zoned: zoned, recurRule: recurRule, pageRule: pageRule, pagesOk: pagesOk, pageLang: pageLang,
    pick: pick, goal: goal, money: money, hash12: hash12, normalize: normalize, select: select, LABELS: LABELS, ALLOWED: ALLOWED
  };
})();
if (typeof module === 'object' && module.exports) { module.exports = ABPCore; }

/* Announcement Bar Pro Embed — builds the bars from a JSON config with DOM methods (createElement, textContent,
   CSSOM styles: no innerHTML of config text, no eval, no inline style attributes), then hands them to the shared
   storefront scripts (window.abpPre + window.AnnouncementBarPro), the same files as the OpenCart and WordPress editions.
   The only innerHTML is the fixed icon markup below (constants, like the storefront script's own tab icon).
   No server of ours: the only requests are this script's own stylesheet and, when data-config is a URL, that JSON file. */
(function () {
  'use strict';

  if (window.ABP && window.ABP.version) { return; } // included twice: keep the first
  var VERSION = '1.0.0', C = ABPCore, doc = document;
  var me = doc.currentScript;
  var opt = function (k) { return me ? me.getAttribute('data-' + k) : null; };
  var nonce = (me && me.nonce) || opt('nonce') || '';
  var cfg = null, ctx = null, cart = null, bars = [];
  function warn(t) { try { if (window.console) { console.warn('Announcement Bar Pro: ' + t); } } catch (e) { /* no console */ } }

  /* ---------------- Small DOM helpers ---------------- */
  function el(tag, cls, attrs, kids) {
    var e = doc.createElement(tag);
    if (cls) { e.className = cls; }
    for (var k in attrs || {}) { if (attrs[k] !== null && attrs[k] !== undefined && attrs[k] !== false) { e.setAttribute(k, attrs[k] === true ? '1' : String(attrs[k])); } }
    (kids || []).forEach(function (c) { if (c !== null && c !== undefined && c !== '') { e.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c); } });
    return e;
  }
  // Icons: fixed markup (the same SVG as the OpenCart / WordPress template), never built from config text.
  var SV = '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"', ST = ' fill="none" stroke="currentColor" stroke-width="';
  function svg(cls, inner) { return SV + (cls ? ' class="' + cls + '"' : '') + '>' + inner + '</svg>'; }
  function line(d, w) { return '<path d="' + d + '"' + ST + (w || '1.8') + '" stroke-linecap="round" stroke-linejoin="round"/>'; }
  function icon(e, html) { e.innerHTML = html; return e; }
  // Node tree of the allow-list (core.parseHtml) → DOM. Text is always a text node.
  function build(nodes, parent, inLink) {
    nodes.forEach(function (n) {
      if (typeof n === 'string') { parent.appendChild(doc.createTextNode(n)); return; }
      if (n.t === 'cd') { parent.appendChild(el('span', 'abp-countdown', { 'data-end': n.end || null, 'data-recur': n.recur || null })); return; }
      if (n.t === 'rem' || n.t === 'goal') { parent.appendChild(el('span', 'abp-' + (n.t === 'rem' ? 'remaining' : 'goal'), null, [n.v])); return; }
      var a = n.t === 'a', u = a && !inLink && C.url(n.href); // checked again: the tree may come from anywhere
      if (!C.ALLOWED[n.t] || (a && !u)) { build(n.c, parent, inLink); return; } // unwrapped: its text stays
      var e = el(n.t);
      if (u) { e.setAttribute('href', u); if (n.blank) { e.setAttribute('target', '_blank'); e.setAttribute('rel', 'noopener noreferrer'); } }
      build(n.c, e, inLink || a);
      parent.appendChild(e);
    });
  }
  function textOf(v) {
    var t = el('span', 'abp-txt');
    if (v.m.length) {
      var d = el('span', 'abp-text abp-text-d'), m = el('span', 'abp-text abp-text-m');
      build(v.d, d); build(v.m, m); t.appendChild(d); t.appendChild(m);
    } else { var x = el('span', 'abp-text'); build(v.d, x); t.appendChild(x); }
    return t;
  }
  // Visitor-facing labels: settings.labels[lang][key], else English (only ever used as text / attribute values).
  function label(k) { var l = cfg.settings.labels, v = (l[ctx.lang] || {})[k] || (l[cfg.settings.default_language] || {})[k]; return typeof v === 'string' && v.trim() ? v.slice(0, 80) : C.LABELS[k]; }

  /* ---------------- One message (same markup as the OpenCart / WordPress template) ---------------- */
  function item(it, first, s) {
    var m = it.m, vis = m.visitor !== 'all' && m.visitor, e = el('div', 'abp-item' + (first ? ' abp-active' : ''), {
      'data-id': m.id, 'data-key': it.key, 'data-style': m.style, 'data-c': m.bg_color, 'data-t': m.text_color,
      'data-device': m.device !== 'all' && m.device, 'data-end': it.end || null,
      'data-fs': it.fs, 'data-done': it.fs && it.goal && it.goal.done, 'data-wd': m.weekdays || null,
      'data-t1': m.time_start || null, 'data-t2': m.time_end || null, 'data-font': m.font || null, 'data-img': !!m.image,
      'data-utm': it.utm || null, 'data-vis': vis, 'data-uoff': !!(it.utm || vis), 'data-trig': it.trig || null, 'data-toff': !!it.trig,
      'data-coff': it.fs && !it.goal // free shipping waits for the cart (ABP.setCart)
    });
    var st = e.style;
    st.backgroundColor = m.bg_color; st.color = m.text_color; st.paddingTop = st.paddingBottom = s.padding + 'px';
    st.setProperty('--abp-btn-bg', m.text_color); st.setProperty('--abp-btn-fg', m.bg_color); st.setProperty('--abp-accent', m.text_color);
    if (m.image) {
      var h = m.bg_color, tint = 'rgba(' + [1, 3, 5].map(function (i) { return parseInt(h.substr(i, 2), 16); }).join(',') + ',' + (m.overlay / 100).toFixed(2) + ')';
      st.backgroundImage = 'linear-gradient(' + tint + ',' + tint + '),url("' + m.image + '")'; // URL checked: no quotes, parentheses kept inside quotes
      st.backgroundSize = 'cover'; st.backgroundPosition = 'center';
    }
    var inner = el('div', 'abp-inner');
    [it.v].forEach(function (v) {
      var lk = { href: m.link, target: m.new_tab && '_blank', rel: m.new_tab && 'noopener noreferrer' }, body = v.wrap ? el('a', 'abp-link abp-body', lk) : el('span', 'abp-body');
      if (m.icon) { body.appendChild(el('span', 'abp-ico', { 'aria-hidden': 'true' }, [m.icon])); body.appendChild(doc.createTextNode(' ')); }
      body.appendChild(textOf(v));
      var wrap = el('span', 'abp-v abp-v-a', null, [body]);
      if (m.link && v.link_text) { wrap.appendChild(el('a', 'abp-btn abp-btn-' + m.button_style, lk, [v.link_text])); }
      inner.appendChild(wrap);
    });
    if (m.coupon) {
      inner.appendChild(el('span', 'abp-coupon', null, [
        el('span', 'abp-code', null, [m.coupon]),
        (function () {
          var c = icon(el('button', 'abp-copy', { type: 'button', 'data-code': m.coupon, 'data-label': label('copy'), 'data-copied': label('copied'), 'aria-label': label('copy_code').replace('%s', m.coupon) }),
            svg('abp-cp', '<rect x="5.2" y="5.2" width="8.6" height="8.6" rx="1.8"' + ST + '1.5"/>' + line('M10.6 3.1V3A1.5 1.5 0 0 0 9.1 1.5H3A1.5 1.5 0 0 0 1.5 3v6.1a1.5 1.5 0 0 0 1.5 1.5h.1', '1.5')) + svg('abp-ok', line('M3 8.6l3.3 3.1L13 4.6', '1.9')));
          c.appendChild(el('span', 'abp-copy-label', null, [label('copy')])); // label text: a text node
          return c;
        })(),
        el('span', 'abp-sr', { role: 'status', 'aria-live': 'polite' })
      ]));
    }
    e.appendChild(inner);
    if (it.fs && m.progress_bar) {
      var fill = el('span', 'abp-progress-fill');
      fill.style.width = (it.goal ? it.goal.pct : 0) + '%';
      e.appendChild(el('span', 'abp-progress', { 'aria-hidden': 'true', 'data-p': it.goal ? it.goal.pct : 0 }, [fill]));
    }
    return e;
  }

  /* ---------------- One bar ---------------- */
  function bar(place, items, id) {
    var s = cfg.settings, mode = s.mode, n = items.length;
    var arrows = mode === 'rotate' && n > 1 && s.arrows, pause = s.pause_button && ((mode === 'rotate' && n > 1) || mode === 'marquee');
    var b = el('div', 'abp abp-bar abp-pos-' + place + (place === 'top' && s.sticky ? ' abp-sticky' : '') + ' abp-mode-' + mode + ' abp-tr-' + s.transition +
      (s.dismissible ? ' abp-has-close' : '') + (arrows ? ' abp-has-nav' : '') + (pause ? ' abp-has-pause' : '') + (s.font ? ' abp-font-' + s.font : ''), {
      id: id, 'data-abp': 'bar', 'data-place': place, role: 'region', 'aria-label': label('label'), 'data-days': s.dismiss_days, 'data-interval': s.interval,
      'data-speed': s.speed, 'data-mode': mode, 'data-tz': ctx.tzSec, 'data-color': s.color_mode, 'data-dismissible': s.dismissible,
      'data-days-label': label('days'), 'data-max': s.max_messages || null, 'data-autohide': s.autohide || null,
      'data-l-show': s.autohide ? label('show') : null, 'data-l-pause': pause ? label('pause') : null, 'data-l-play': pause ? label('play') : null,
      'data-ga': s.ga4, 'data-consent': s.consent_wait
    });
    b.style.fontSize = s.font_size + 'px'; b.style.backgroundColor = items[0].m.bg_color; b.style.color = items[0].m.text_color;
    var track = el('div', 'abp-track');
    items.forEach(function (it, i) { track.appendChild(item(it, i === 0, s)); });
    b.appendChild(el('div', 'abp-viewport', null, [track]));
    var btn = function (cls, lab, html) { b.appendChild(icon(el('button', cls, { type: 'button', 'aria-label': lab, title: lab, 'aria-pressed': cls === 'abp-pause' ? 'false' : null }), html)); };
    if (pause) { btn('abp-pause', label('pause'), svg('abp-i-pause', line('M5.5 3.5v9m5-9v9', '2')) + svg('abp-i-play', '<path d="M5 3.2v9.6L12.6 8z" fill="currentColor"/>')); }
    if (arrows) { btn('abp-nav abp-prev', label('prev'), svg('', line('M10 3 5 8l5 5'))); btn('abp-nav abp-next', label('next'), svg('', line('m6 3 5 5-5 5'))); }
    if (s.dismissible) { btn('abp-close', label('close'), svg('', line('M3.5 3.5l9 9m0-9-9 9'))); }
    return b;
  }

  /* ---------------- Render ---------------- */
  function context() {
    var s = cfg.settings, now = Date.now(), loc = window.location;
    var tz = s.timezone || (window.Intl && Intl.DateTimeFormat().resolvedOptions().timeZone) || 'UTC';
    s.timezone = tz;
    return { now: now, tzSec: C.tzOffset(tz, now), cart: cart, loc: loc,
      lang: C.pageLang(doc.documentElement.getAttribute('lang'), loc, s.languages, s.default_language) };
  }
  function render() {
    ctx = context();
    var groups = C.select(cfg, ctx), list = [];
    ['top', 'bottom'].forEach(function (place) {
      if (!groups[place].length) { return; }
      var b = bar(place, groups[place], list.length ? 'abp-bar-bottom' : 'abp-bar'); // ids as in the other editions
      if (place === 'top') { doc.body.insertBefore(b, doc.body.firstChild); } else { doc.body.appendChild(b); }
      list.push(b);
    });
    bars = list;
    if (cfg.settings.custom_css) { addCss(cfg.settings.custom_css); }
    try { if (window.AnnouncementBarPro) { window.AnnouncementBarPro.scan(); } } catch (e) { warn(e.message); }
  }
  // Custom CSS (already filtered): with the script's nonce when the page has a Content-Security-Policy, else a
  // constructed stylesheet (needs no 'unsafe-inline'), else a <style> element.
  function addCss(text) {
    if (!nonce && doc.adoptedStyleSheets && window.CSSStyleSheet) {
      try { var sh = new CSSStyleSheet(); sh.replaceSync(text); doc.adoptedStyleSheets = doc.adoptedStyleSheets.concat([sh]); return; } catch (e) { /* fall back */ }
    }
    var st = el('style', '', { nonce: nonce || null });
    st.textContent = text;
    (doc.head || doc.documentElement).appendChild(st);
  }

  /* ---------------- Cart adapter: free-shipping progress ----------------
     The page tells the bar what is in the cart: ABP.setCart({subtotal: 42.5, currency: 'EUR', count: 2}). Nothing is
     fetched by this script. Until the first call, free-shipping messages stay hidden. */
  function setCart(c) {
    if (!c || typeof c !== 'object' || isNaN(+c.subtotal)) { warn('setCart: {subtotal, currency, count}'); return; }
    cart = { subtotal: Math.max(0, +c.subtotal), currency: /^[A-Za-z]{3}$/.test(c.currency) ? c.currency.toUpperCase() : '' }; // '' = the config's currency
    if (!cfg || !ctx) { return; }
    ctx.cart = cart; ctx.now = Date.now();
    var groups = C.select(cfg, ctx);
    bars.forEach(function (b) {
      if (!doc.documentElement.contains(b)) { return; }
      var fresh = {};
      (groups[b.getAttribute('data-place')] || []).forEach(function (it) { fresh[it.id] = it; });
      Array.prototype.forEach.call(b.querySelectorAll('.abp-item[data-fs="1"]'), function (e) {
        var it = fresh[e.getAttribute('data-id')], g = it && it.goal, t = e.querySelector('.abp-txt'), fill = e.querySelector('.abp-progress-fill');
        if (!g) { e.setAttribute('data-coff', '1'); return; } // no amount for this currency
        e.removeAttribute('data-coff');
        if (t) { t.parentNode.replaceChild(textOf(it.v), t); }
        if (g.done) { e.setAttribute('data-done', '1'); } else { e.removeAttribute('data-done'); }
        if (fill) { fill.style.width = g.pct + '%'; fill.parentNode.setAttribute('data-p', String(g.pct)); }
      });
      if (b.abpApi) { b.abpApi.refresh(); b.abpApi.relayout(); }
    });
  }

  /* ---------------- Start ---------------- */
  function loadCss(done) {
    var href = opt('css');
    if (href === 'none') { done(); return; }
    href = href ? C.url(href) : me && me.src ? me.src.replace(/\.js(\?|#|$)/, '.css$1') : '';
    if (!href) { done(); return; }
    var ok = false, fin = function () { if (!ok) { ok = true; done(); } };
    var l = el('link', '', { rel: 'stylesheet', href: href, nonce: nonce || null });
    l.onload = fin; l.onerror = function () { warn('no CSS ' + href); fin(); };
    setTimeout(fin, 3000);
    (doc.head || doc.documentElement).appendChild(l);
  }
  function loadConfig(done) {
    var src = opt('config') || '#abp-config';
    if (window.abpConfig && typeof window.abpConfig === 'object' && !opt('config')) { done(window.abpConfig); return; }
    if (src.charAt(0) === '#') {
      var tag = doc.getElementById(src.slice(1));
      if (!tag) { warn('no config ' + src); return; }
      try { done(JSON.parse(tag.textContent)); } catch (e) { warn('bad JSON'); }
      return;
    }
    var u = C.url(src);
    if (!u || !window.fetch) { warn('bad config URL'); return; }
    window.fetch(u, { credentials: 'omit', headers: { Accept: 'application/json' } })
      .then(function (r) { if (!r.ok) { throw new Error('HTTP ' + r.status); } return r.json(); })
      .then(done, function (e) { warn('config: ' + e.message); });
  }
  function start() {
    var pending = 2, json = null;
    var go = function () {
      if (--pending) { return; }
      try { cfg = C.normalize(json); if (cfg.messages.length) { render(); } } catch (e) { warn(e.message); }
      if (window.abpCart) { setCart(window.abpCart); }
    };
    loadConfig(function (j) { json = j; go(); });
    loadCss(go);
  }

  window.ABP = {
    version: VERSION,
    setCart: setCart
  };
  if (doc.readyState === 'loading') { doc.addEventListener('DOMContentLoaded', start); } else { start(); }
})();
})();
